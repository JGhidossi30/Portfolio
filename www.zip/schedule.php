<?php
require ("fpdf/fpdf.php");

//Themes
if ($_POST['theme'] == "Colored")
{
	//Create Blocks
	class PDF extends FPDF
	{
		function sec($z, $day, $period, $time1, $time2)
		{
			if ($z == 1)
				$this->SetFillColor(176, 223, 229);
			else if ($z == 2)
				$this->SetFillColor(255, 77, 77);
			else if ($z == 3)
				$this->SetFillColor(254, 218, 186);
			else if ($z == 4)
				$this->SetFillColor(254, 215, 0);
			else if ($z == 5)
				$this->SetFillColor(148, 112, 220);
			else if ($z == 6)
				$this->SetFillColor(144, 238, 144);
			else if ($z == 7)
				$this->SetFillColor(255, 153, 255);
			else if ($z == 8)
				$this->SetFillColor(252, 228, 133);
			if ($_POST['sec' . $z . '-free'] == "true")
			{	
				for ($i = 1; $i <= 8; $i++)
				{
					if (substr($_POST['sec' . $i . '-secnum'], 1, 1) == $z)
					{
						if (isset($_POST['sec' . $i . '-doublelabs']))
						{
							foreach($_POST['sec' . $i . '-doublelabs'] as $j)
							{
								if ($day == $j)
									return 1;
							}
						}
						for ($j = 1; $j <= 8; $j++)
						{
							if ($day == $_POST['sec' . $j . '-switchfourth'] AND $period == 4)
							{
								if ($j == 1)
									$this->SetFillColor(176, 223, 229);
								else if ($j == 2)
									$this->SetFillColor(255, 77, 77);
								else if ($j == 3)
									$this->SetFillColor(254, 218, 186);
								else if ($j == 4)
									$this->SetFillColor(254, 215, 0);
								else if ($j == 5)
									$this->SetFillColor(148, 112, 220);
								else if ($j == 6)
									$this->SetFillColor(144, 238, 144);
								else if ($j == 7)
									$this->SetFillColor(255, 153, 255);
								else if ($j == 8)
									$this->SetFillColor(252, 228, 133);
								$this->SetFont("Times", '', 6);
								$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
								$this->SetFont("Times", 'B', 6);
								if (strlen($_POST['sec' . $j . '-name']) < 18)
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								else
								{
									$this->SetFont("Times", 'B', 5);
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								}
								$this->SetFont("Times", '', 6);
								if (strlen($_POST['sec' . $j . '-teacher']) < 20)
								{
								$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-teacher'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
								}
								else
								{
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 0, 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								}	
								return;
							}
						}
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
			}
			else
			{
				if (substr($_POST['sec' . $z . '-secnum'], 0, 1) != substr($_POST['sec' . $z . '-secnum'], 1, 1))
				{
					if (isset($_POST['sec' . $z . '-doublelabs']))
					{
						foreach($_POST['sec' . $z . '-doublelabs'] as $i)
						{
							if ($day == $i)
							{
								$this->doublelab($time1, $time2, $z);
								return 2;
							}
						}
					}
					if ($day == $_POST['sec' . $z . '-switchfourth'])
					{
						if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 1)
							$this->SetFillColor(176, 223, 229);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 2)
							$this->SetFillColor(255, 77, 77);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 3)
							$this->SetFillColor(254, 218, 186);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 4)
							$this->SetFillColor(254, 215, 0);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 5)
							$this->SetFillColor(148, 112, 220);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 6)
							$this->SetFillColor(144, 238, 144);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 7)
							$this->SetFillColor(255, 153, 255);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 8)
							$this->SetFillColor(252, 228, 133);
						$this->SetFont("Times", '', 6);
						$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
						$this->SetFont("Times", 'B', 6);
						$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
						return;
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				if (strlen($_POST['sec' . $z . '-name']) < 18)
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				else if (strlen($_POST['sec' . $z . '-name']) < 20)
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				}
				else
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'C', true);
				}
				$this->SetFont("Times", '', 6);
				if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
				{
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
				}
				else
				{
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				}
			}
		}
		public function secX()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 4.5, "-", 'RTL', 2, 'L', true);
			$this->Cell(19.75, 4.5, substr(2000 + $_POST['fyear'] - $_POST['grade'] - 5, 2, 2) . $_POST['grade'] . "-3", 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Advisory - " . $_POST['grade'], 'RL', 2, 'L', true);
			$this->SetFont("Times", '', 6);
			$this->Cell(19.75, 4.5, $_POST['advisor'] . "/" . $_POST['lcounc'], 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Room: " . $_POST['adv-rm'], 'RBL', 2, 'L', true);
		}
		public function secMISC()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 5, "EMPTY", 1, 2, 'C', true);
		}
		function doublelab($time1, $time2, $z)
		{
			//Times
			$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));
		
			$this->SetFont("Times", '', 6);
			for ($i = 0; $i < 7; $i++)
				if ($times[$i][1] == $time2)
				{
					if ($i == 6)
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i][1], 'RTL', 2, 'C', true);
					else
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i + 1][1], 'RTL', 2, 'C', true);
				}	
			$this->SetFont("Times", 'B', 6);
			if (strlen($_POST['sec' . $z . '-name']) < 18)
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			else
			{
				$this->SetFont("Times", 'B', 5);
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			}
			$this->SetFont("Times", '', 6);
			if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
			{
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 33, "", 'RBL', 2, 'L', true);
			}
			else
			{
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 27.5, "", 'RBL', 2, 'L', true);
			}
		}
	}
	
	//Times
	$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));

	//Create PDF
	$pdf = new PDF();

	//Set Page
	$pdf->SetTitle($_POST['fname'] . " " . $_POST['lname'] . "'s Schedule " . $_POST['fyear'] . "-" . $_POST['lyear']);
	$pdf->SetMargins(22, 17.5, 23);
	$pdf->SetLineWidth(.1);
	$pdf->AddPage();

	//Header
	$pdf->SetFillColor(255, 255, 255);
	$pdf->Cell(77, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 4, $_POST['fyear'] . "-" . $_POST['lyear'], 'RL', 0, 'C', true);
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(0, 4, "Student Schedule for " . $_POST['lname'] . ", " . $_POST['fname'] . " " . $_POST['minitial'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 5.66, "Ridgefield High School", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	if (strlen($_POST['studentnum']) == 0)
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Student Number: " . $_POST['studentnum'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	$pdf->Ln();
	$pdf->SetFont("Times", '', 10);
	$pdf->Cell(77, 4, "700 N Salem Rd, Ridgefield CT 06877", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	$pdf->Cell(0, 4, "Term Q1 Q2 Q3 Q4   Courses enrolled: " . $_POST['enrolled'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->Cell(77, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Ln(10);

	//First Line
	$pdf->SetFillColor(230, 230, 230);
	$pdf->SetFont("Times", 'B', 8);
	$pdf->Cell(7, 10, "", 1, 0, 'C', true);
	if ($_POST['semester'] == 1)
	{
		$pdf->Cell(0, 5, "Term Q1 Q2", 1, 2, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5, "Term Q3 Q4", 1, 2, 'C', true);
	}
	$pdf->Cell(19.75, 5, "A", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "B", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "C", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "D", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "E", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "F", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "G", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "H", 1, 0, 'C', true);
	$pdf->Ln();

	//Periods
	$pdf->Cell(7, 27.5, "1st", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "2nd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "3rd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "4th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "5th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "6th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "7th", 1, 2, 'C', true);
	$pdf->Cell(7, 22.5, "X", 1, 2, 'C', true);
	$pdf->SetFont("Times", 'B', 7);
	$pdf->Cell(7, 5, "MISC", 1, 0, 'C', true);
	
	//A Day
	$pdf->SetXY(29, 52.8);
	$inc = 0;
	for ($a = 0; $a < 7; $a++)
	{
		if ($inc == 0)
		{
			$a1 = $pdf->sec(1, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a1 == 1)
				$a--;
			else if ($a1 == 2)
				$a++;
		}
		else if ($inc == 1)
		{
			$a2 = $pdf->sec(2, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a2 == 1)
				$a--;
			else if ($a2 == 2)
				$a++;
		}
		else if ($inc == 2)
		{
			$a3 = $pdf->sec(3, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a3 == 1)
				$a--;
			else if ($a3 == 2)
				$a++;
		}
		else if ($inc == 3)
		{
			$a4 = $pdf->sec(4, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a4 == 1)
				$a--;
			else if ($a4 == 2)
				$a++;
		}
		else if ($inc == 4)
		{
			$a5 = $pdf->sec(5, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a5 == 1)
				$a--;
			else if ($a5 == 2)
				$a++;
		}
		else if ($inc == 5)
		{
			$a6 = $pdf->sec(6, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a6 == 1)
				$a--;
			else if ($a6 == 2)
				$a++;
		}
		else if ($inc == 6)
		{
			$a7 = $pdf->sec(7, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a7 == 1)
				$a--;
			else if ($a7 == 2)
				$a++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//B Day
	$pdf->SetXY(48.75, 52.8);
	$inc = 0;
	for ($b = 0; $b < 7; $b++)
	{
		if ($inc == 0)
		{
			$b1 = $pdf->sec(2, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b1 == 1)
				$b--;
			else if ($b1 == 2)
				$b++;
		}
		else if ($inc == 1)
		{
			$b2 = $pdf->sec(3, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b2 == 1)
				$b--;
			else if ($b2 == 2)
				$b++;
		}
		else if ($inc == 2)
		{
			$b3 = $pdf->sec(1, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b3 == 1)
				$b--;
			else if ($b3 == 2)
				$b++;
		}
		else if ($inc == 3)
		{
			$b4 = $pdf->sec(7, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b4 == 1)
				$b--;
			else if ($b4 == 2)
				$b++;
		}
		else if ($inc == 4)
		{
			$b5 = $pdf->sec(8, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b5 == 1)
				$b--;
			else if ($b5 == 2)
				$b++;
		}
		else if ($inc == 5)
		{
			$b6 = $pdf->sec(5, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b6 == 1)
				$b--;
			else if ($b6 == 2)
				$b++;
		}
		else if ($inc == 6)
		{
			$b7 = $pdf->sec(6, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b7 == 1)
				$b--;
			else if ($b7 == 2)
				$b++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//C Day
	$pdf->SetXY(68.5, 52.8);
	$inc = 0;
	for ($c = 0; $c < 7; $c++)
	{
		if ($inc == 0)
		{
			$c1 = $pdf->sec(3, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c1 == 1)
				$c--;
			else if ($c1 == 2)
				$c++;
		}
		else if ($inc == 1)
		{
			$c2 = $pdf->sec(1, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c2 == 1)
				$c--;
			else if ($c2 == 2)
				$c++;
		}
		else if ($inc == 2)
		{
			$c3 = $pdf->sec(4, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c3 == 1)
				$c--;
			else if ($c3 == 2)
				$c++;
		}
		else if ($inc == 3)
		{
			$c4 = $pdf->sec(2, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c4 == 1)
				$c--;
			else if ($c4 == 2)
				$c++;
		}
		else if ($inc == 4)
		{
			$c5 = $pdf->sec(6, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c5 == 1)
				$c--;
			else if ($c5 == 2)
				$c++;
		}
		else if ($inc == 5)
		{
			$c6 = $pdf->sec(8, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c6 == 1)
				$c--;
			else if ($c6 == 2)
				$c++;
		}
		else if ($inc == 6)
		{
			$c7 = $pdf->sec(5, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c7 == 1)
				$c--;
			else if ($c7 == 2)
				$c++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//D Day
	$pdf->SetXY(88.25, 52.8);
	$inc = 0;
	for ($d = 0; $d < 7; $d++)
	{
		if ($inc == 0)
		{
			$d1 = $pdf->sec(1, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d1 == 1)
				$d--;
			else if ($d1 == 2)
				$d++;
		}
		else if ($inc == 1)
		{
			$d2 = $pdf->sec(4, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d2 == 1)
				$d--;
			else if ($d2 == 2)
				$d++;
		}
		else if ($inc == 2)
		{
			$d3 = $pdf->sec(3, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d3 == 1)
				$d--;
			else if ($d3 == 2)
				$d++;
		}
		else if ($inc == 3)
		{
			$d4 = $pdf->sec(5, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d4 == 1)
				$d--;
			else if ($d4 == 2)
				$d++;
		}
		else if ($inc == 4)
		{
			$d5 = $pdf->sec(7, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d5 == 1)
				$d--;
			else if ($d5 == 2)
				$d++;
		}
		else if ($inc == 5)
		{
			$d6 = $pdf->sec(6, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d6 == 1)
				$d--;
			else if ($d6 == 2)
				$d++;
		}
		else if ($inc == 6)
		{
			$d7 = $pdf->sec(8, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d7 == 1)
				$d--;
			else if ($d7 == 2)
				$d++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//E Day
	$pdf->SetXY(108, 52.8);
	$inc = 0;
	for ($e = 0; $e < 7; $e++)
	{
		if ($inc == 0)
		{
			$e1 = $pdf->sec(4, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e1 == 1)
				$e--;
			else if ($e1 == 2)
				$e++;
		}
		else if ($inc == 1)
		{
			$e2 = $pdf->sec(3, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e2 == 1)
				$e--;
			else if ($e2 == 2)
				$e++;
		}
		else if ($inc == 2)
		{
			$e3 = $pdf->sec(2, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e3 == 1)
				$e--;
			else if ($e3 == 2)
				$e++;
		}
		else if ($inc == 3)
		{
			$e4 = $pdf->sec(1, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e4 == 1)
				$e--;
			else if ($e4 == 2)
				$e++;
		}
		else if ($inc == 4)
		{
			$e5 = $pdf->sec(8, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e5 == 1)
				$e--;
			else if ($e5 == 2)
				$e++;
		}
		else if ($inc == 5)
		{
			$e6 = $pdf->sec(7, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e6 == 1)
				$e--;
			else if ($e6 == 2)
				$e++;
		}
		else if ($inc == 6)
		{
			$e7 = $pdf->sec(6, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e7 == 1)
				$e--;
			else if ($e7 == 2)
				$e++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//F Day
	$pdf->SetXY(127.75, 52.8);
	$inc = 0;
	for ($f = 0; $f < 7; $f++)
	{
		if ($inc == 0)
		{
			$f1 = $pdf->sec(3, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f1 == 1)
				$f--;
			else if ($f1 == 2)
				$f++;
		}
		else if ($inc == 1)
		{
			$f2 = $pdf->sec(2, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f2 == 1)
				$f--;
			else if ($f2 == 2)
				$f++;
		}
		else if ($inc == 2)
		{
			$f3 = $pdf->sec(4, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f3 == 1)
				$f--;
			else if ($f3 == 2)
				$f++;
		}
		else if ($inc == 3)
		{
			$f4 = $pdf->sec(6, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f4 == 1)
				$f--;
			else if ($f4 == 2)
				$f++;
		}
		else if ($inc == 4)
		{
			$f5 = $pdf->sec(5, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f5 == 1)
				$f--;
			else if ($f5 == 2)
				$f++;
		}
		else if ($inc == 5)
		{
			$f6 = $pdf->sec(8, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f6 == 1)
				$f--;
			else if ($f6 == 2)
				$f++;
		}
		else if ($inc == 6)
		{
			$f7 = $pdf->sec(7, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f7 == 1)
				$f--;
			else if ($f7 == 2)
				$f++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//G Day
	$pdf->SetXY(147.5, 52.8);
	$inc = 0;
	for ($g = 0; $g < 7; $g++)
	{
		if ($inc == 0)
		{
			$g1 = $pdf->sec(2, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g1 == 1)
				$g--;
			else if ($g1 == 2)
				$g++;
		}
		else if ($inc == 1)
		{
			$g2 = $pdf->sec(4, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g2 == 1)
				$g--;
			else if ($g2 == 2)
				$g++;
		}
		else if ($inc == 2)
		{
			$g3 = $pdf->sec(1, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g3 == 1)
				$g--;
			else if ($g3 == 2)
				$g++;
		}
		else if ($inc == 3)
		{
			$g4 = $pdf->sec(3,"G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g4 == 1)
				$g--;
			else if ($g4 == 2)
				$g++;
		}
		else if ($inc == 4)
		{
			$g5 = $pdf->sec(7, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g5 == 1)
				$g--;
			else if ($g5 == 2)
				$g++;
		}
		else if ($inc == 5)
		{
			$g6 = $pdf->sec(5, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g6 == 1)
				$g--;
			else if ($g6 == 2)
				$g++;
		}
		else if ($inc == 6)
		{
			$g7 = $pdf->sec(8, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g7 == 1)
				$g--;
			else if ($g7 == 2)
				$g++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//H Day
	$pdf->SetXY(167.25, 52.8);
	$inc = 0;
	for ($h = 0; $h < 7; $h++)
	{
		if ($inc == 0)
		{
			$h1 = $pdf->sec(4, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h1 == 1)
				$h--;
			else if ($h1 == 2)
				$h++;
		}
		else if ($inc == 1)
		{
			$h2 = $pdf->sec(1, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h2 == 1)
				$h--;
			else if ($h2 == 2)
				$h++;
		}
		else if ($inc == 2)
		{
			$h3 = $pdf->sec(2, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h3 == 1)
				$h--;
			else if ($h3 == 2)
				$h++;
		}
		else if ($inc == 3)
		{
			$h4 = $pdf->sec(8, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h4 == 1)
				$h--;
			else if ($h4 == 2)
				$h++;
		}
		else if ($inc == 4)
		{
			$h5 = $pdf->sec(6, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h5 == 1)
				$h--;
			else if ($h5 == 2)
				$h++;
		}
		else if ($inc == 5)
		{
			$h6 = $pdf->sec(7, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h6 == 1)
				$h--;
			else if ($h6 == 2)
				$h++;
		}
		else if ($inc == 6)
		{
			$h7 = $pdf->sec(5, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h7 == 1)
				$h--;
			else if ($h7 == 2)
				$h++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
}
else if ($_POST['theme'] == "Tigers")
{
	//Create Blocks
	class PDF extends FPDF
	{
		function sec($z, $day, $period, $time1, $time2)
		{
			if ($_POST['sec' . $z . '-free'] == "true")
			{	
				for ($i = 1; $i <= 8; $i++)
				{
					if (substr($_POST['sec' . $i . '-secnum'], 1, 1) == $z)
					{
						if (isset($_POST['sec' . $i . '-doublelabs']))
						{
							foreach($_POST['sec' . $i . '-doublelabs'] as $j)
							{
								if ($day == $j)
									return 1;
							}
						}
						for ($j = 1; $j <= 8; $j++)
						{
							if ($day == $_POST['sec' . $j . '-switchfourth'] AND $period == 4)
							{
								$this->SetFont("Times", '', 6);
								$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
								$this->SetFont("Times", 'B', 6);
								if (strlen($_POST['sec' . $j . '-name']) < 18)
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								else
								{
									$this->SetFont("Times", 'B', 5);
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								}
								$this->SetFont("Times", '', 6);
								if (strlen($_POST['sec' . $j . '-teacher']) < 20)
								{
								$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-teacher'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
								}
								else
								{
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 0, 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								}	
								return;
							}
						}
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
			}
			else
			{
				if (substr($_POST['sec' . $z . '-secnum'], 0, 1) != substr($_POST['sec' . $z . '-secnum'], 1, 1))
				{
					if (isset($_POST['sec' . $z . '-doublelabs']))
					{
						foreach($_POST['sec' . $z . '-doublelabs'] as $i)
						{
							if ($day == $i)
							{
								$this->doublelab($time1, $time2, $z);
								return 2;
							}
						}
					}
					if ($day == $_POST['sec' . $z . '-switchfourth'])
					{
						$this->SetFont("Times", '', 6);
						$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
						$this->SetFont("Times", 'B', 6);
						$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
						return;
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				if (strlen($_POST['sec' . $z . '-name']) < 18)
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				else if (strlen($_POST['sec' . $z . '-name']) < 20)
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				}
				else
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'C', true);
				}
				$this->SetFont("Times", '', 6);
				if (strlen($_POST['sec' . $z . '-teacher']) < 21)
				{
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
				}
				else
				{
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 21), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 21), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				}
			}
		}
		public function secX()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 4.5, "-", 'RTL', 2, 'L', true);
			$this->Cell(19.75, 4.5, substr(2000 + $_POST['fyear'] - $_POST['grade'] - 5, 2, 2) . $_POST['grade'] . "-3", 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Advisory - " . $_POST['grade'], 'RL', 2, 'L', true);
			$this->SetFont("Times", '', 6);
			$this->Cell(19.75, 4.5, $_POST['advisor'] . "/" . $_POST['lcounc'], 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Room: " . $_POST['adv-rm'], 'RBL', 2, 'L', true);
		}
		public function secMISC()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 5, "EMPTY", 1, 2, 'C', true);
		}
		function doublelab($time1, $time2, $z)
		{
			//Times
			$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));
		
			$this->SetFont("Times", '', 6);
			for ($i = 0; $i < 7; $i++)
				if ($times[$i][1] == $time2)
				{
					if ($i == 6)
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i][1], 'RTL', 2, 'C', true);
					else
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i + 1][1], 'RTL', 2, 'C', true);
				}	
			$this->SetFont("Times", 'B', 6);
			if (strlen($_POST['sec' . $z . '-name']) < 18)
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			else
			{
				$this->SetFont("Times", 'B', 5);
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			}
			$this->SetFont("Times", '', 6);
			if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
			{
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 33, "", 'RBL', 2, 'L', true);
			}
			else
			{
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 27.5, "", 'RBL', 2, 'L', true);
			}
		}
	}
	
	//Times
	$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));

	//Create PDF
	$pdf = new PDF();

	//Set Page
	$pdf->SetTitle($_POST['fname'] . " " . $_POST['lname'] . "'s Schedule " . $_POST['fyear'] . "-" . $_POST['lyear']);
	$pdf->AddPage();
	$pdf->SetAutoPageBreak(false);
	$pdf->SetMargins(0, 0, 0);
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	$pdf->SetFillColor(255, 105, 0);
	$pdf->Rect(0, 0, 210, 297, 'FD');
	$pdf->SetFillColor(0, 0, 0);
	$pdf->Rect(22, 17.5, 165, 16.98, 'F');
	$pdf->Rect(29, 52.8, 19.75, 27.5, 'F');
	$pdf->Rect(48.75, 80.3, 19.75, 27.5, 'F');
	$pdf->Rect(68.5, 52.8, 19.75, 27.5, 'F');
	$pdf->Rect(88.25, 80.3, 19.75, 27.5, 'F');
	$pdf->Rect(108, 52.8, 19.75, 27.5, 'F');
	$pdf->Rect(127.75, 80.3, 19.75, 27.5, 'F');
	$pdf->Rect(147.5, 52.8, 19.75, 27.5, 'F');
	$pdf->Rect(167.25, 80.3, 19.75, 27.5, 'F');
	$pdf->Rect(29, 105, 19.75, 27.5, 'F');
	$pdf->Rect(48.75, 130.78, 19.75, 27.5, 'F');
	$pdf->Rect(68.5, 105, 19.75, 27.5, 'F');
	$pdf->Rect(88.25, 130.78, 19.75, 27.5, 'F');
	$pdf->Rect(108, 105, 19.75, 27.5, 'F');
	$pdf->Rect(127.75, 130.78, 19.75, 27.5, 'F');
	$pdf->Rect(147.5, 105, 19.75, 27.5, 'F');
	$pdf->Rect(167.25, 130.78, 19.75, 27.5, 'F');
	$pdf->Rect(29, 158.28, 19.75, 27.5, 'F');
	$pdf->Rect(68.5, 158.28, 19.75, 27.5, 'F');
	$pdf->Rect(108, 158.28, 19.75, 27.5, 'F');
	$pdf->Rect(147.5, 158.28, 19.75, 27.5, 'F');
	$pdf->Rect(29, 215, 19.75, 27.5, 'F');
	$pdf->Rect(68.5, 215, 19.75, 27.5, 'F');
	$pdf->Rect(108, 215, 19.75, 27.5, 'F');
	$pdf->Rect(147.5, 215, 19.75, 27.5, 'F');
	$pdf->Rect(48.75, 185, 19.75, 27.5, 'F');
	$pdf->Rect(88.25, 185, 19.75, 27.5, 'F');
	$pdf->Rect(127.75, 185, 19.75, 27.5, 'F');
	$pdf->Rect(167.25, 185, 19.75, 27.5, 'F');
	$pdf->SetFillColor(255, 255, 255);
	$pdf->Rect(29, 240, 158, 27.5, 'F');
	$pdf->SetXY(22, 17.5);
	$pdf->SetMargins(22, 17.5, 23);
	$pdf->SetLineWidth(.1);

	//Header
	$pdf->SetFillColor(0, 0, 0);
	$pdf->Cell(77, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 4, $_POST['fyear'] . "-" . $_POST['lyear'], 'RL', 0, 'C', true);
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(0, 4, "Student Schedule for " . $_POST['lname'] . ", " . $_POST['fname'] . " " . $_POST['minitial'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 5.66, "Ridgefield High School", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	if (strlen($_POST['studentnum']) == 0)
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Student Number: " . $_POST['studentnum'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	$pdf->Ln();
	$pdf->SetFont("Times", '', 10);
	$pdf->Cell(77, 4, "700 N Salem Rd, Ridgefield CT 06877", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	$pdf->Cell(0, 4, "Term Q1 Q2 Q3 Q4   Courses enrolled: " . $_POST['enrolled'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->Cell(77, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Ln(10);

	//First Line
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->SetFont("Times", 'B', 8);
	$pdf->Cell(7, 10, "", 1, 0, 'C', true);
	if ($_POST['semester'] == 1)
	{
		$pdf->Cell(0, 5, "Term Q1 Q2", 1, 2, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5, "Term Q3 Q4", 1, 2, 'C', true);
	}
	$pdf->Cell(19.75, 5, "A", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "B", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "C", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "D", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "E", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "F", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "G", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "H", 1, 0, 'C', true);
	$pdf->Ln();

	//Periods
	$pdf->Cell(7, 27.5, "1st", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "2nd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "3rd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "4th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "5th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "6th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "7th", 1, 2, 'C', true);
	$pdf->Cell(7, 22.5, "X", 1, 2, 'C', true);
	$pdf->SetFont("Times", 'B', 7);
	$pdf->Cell(7, 5, "MISC", 1, 0, 'C', true);
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//A Day
	$pdf->SetXY(29, 52.8);
	$inc = 0;
	for ($a = 0; $a < 7; $a++)
	{
		if ($a % 2 == 0)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$a1 = $pdf->sec(1, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a1 == 1)
				$a--;
			else if ($a1 == 2)
				$a++;
		}
		else if ($inc == 1)
		{
			$a2 = $pdf->sec(2, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a2 == 1)
				$a--;
			else if ($a2 == 2)
				$a++;
		}
		else if ($inc == 2)
		{
			$a3 = $pdf->sec(3, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a3 == 1)
				$a--;
			else if ($a3 == 2)
				$a++;
		}
		else if ($inc == 3)
		{
			$a4 = $pdf->sec(4, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a4 == 1)
				$a--;
			else if ($a4 == 2)
				$a++;
		}
		else if ($inc == 4)
		{
			$a5 = $pdf->sec(5, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a5 == 1)
				$a--;
			else if ($a5 == 2)
				$a++;
		}
		else if ($inc == 5)
		{
			$a6 = $pdf->sec(6, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a6 == 1)
				$a--;
			else if ($a6 == 2)
				$a++;
		}
		else if ($inc == 6)
		{
			$a7 = $pdf->sec(7, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a7 == 1)
				$a--;
			else if ($a7 == 2)
				$a++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//B Day
	$pdf->SetXY(48.75, 52.8);
	$inc = 0;
	for ($b = 0; $b < 7; $b++)
	{
		if ($b % 2 == 1)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$b1 = $pdf->sec(2, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b1 == 1)
				$b--;
			else if ($b1 == 2)
				$b++;
		}
		else if ($inc == 1)
		{
			$b2 = $pdf->sec(3, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b2 == 1)
				$b--;
			else if ($b2 == 2)
				$b++;
		}
		else if ($inc == 2)
		{
			$b3 = $pdf->sec(1, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b3 == 1)
				$b--;
			else if ($b3 == 2)
				$b++;
		}
		else if ($inc == 3)
		{
			$b4 = $pdf->sec(7, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b4 == 1)
				$b--;
			else if ($b4 == 2)
				$b++;
		}
		else if ($inc == 4)
		{
			$b5 = $pdf->sec(8, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b5 == 1)
				$b--;
			else if ($b5 == 2)
				$b++;
		}
		else if ($inc == 5)
		{
			$b6 = $pdf->sec(5, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b6 == 1)
				$b--;
			else if ($b6 == 2)
				$b++;
		}
		else if ($inc == 6)
		{
			$b7 = $pdf->sec(6, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b7 == 1)
				$b--;
			else if ($b7 == 2)
				$b++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//C Day
	$pdf->SetXY(68.5, 52.8);
	$inc = 0;
	for ($c = 0; $c < 7; $c++)
	{
		if ($c % 2 == 0)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$c1 = $pdf->sec(3, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c1 == 1)
				$c--;
			else if ($c1 == 2)
				$c++;
		}
		else if ($inc == 1)
		{
			$c2 = $pdf->sec(1, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c2 == 1)
				$c--;
			else if ($c2 == 2)
				$c++;
		}
		else if ($inc == 2)
		{
			$c3 = $pdf->sec(4, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c3 == 1)
				$c--;
			else if ($c3 == 2)
				$c++;
		}
		else if ($inc == 3)
		{
			$c4 = $pdf->sec(2, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c4 == 1)
				$c--;
			else if ($c4 == 2)
				$c++;
		}
		else if ($inc == 4)
		{
			$c5 = $pdf->sec(6, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c5 == 1)
				$c--;
			else if ($c5 == 2)
				$c++;
		}
		else if ($inc == 5)
		{
			$c6 = $pdf->sec(8, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c6 == 1)
				$c--;
			else if ($c6 == 2)
				$c++;
		}
		else if ($inc == 6)
		{
			$c7 = $pdf->sec(5, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c7 == 1)
				$c--;
			else if ($c7 == 2)
				$c++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//D Day
	$pdf->SetXY(88.25, 52.8);
	$inc = 0;
	for ($d = 0; $d < 7; $d++)
	{
		if ($d % 2 == 1)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$d1 = $pdf->sec(1, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d1 == 1)
				$d--;
			else if ($d1 == 2)
				$d++;
		}
		else if ($inc == 1)
		{
			$d2 = $pdf->sec(4, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d2 == 1)
				$d--;
			else if ($d2 == 2)
				$d++;
		}
		else if ($inc == 2)
		{
			$d3 = $pdf->sec(3, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d3 == 1)
				$d--;
			else if ($d3 == 2)
				$d++;
		}
		else if ($inc == 3)
		{
			$d4 = $pdf->sec(5, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d4 == 1)
				$d--;
			else if ($d4 == 2)
				$d++;
		}
		else if ($inc == 4)
		{
			$d5 = $pdf->sec(7, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d5 == 1)
				$d--;
			else if ($d5 == 2)
				$d++;
		}
		else if ($inc == 5)
		{
			$d6 = $pdf->sec(6, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d6 == 1)
				$d--;
			else if ($d6 == 2)
				$d++;
		}
		else if ($inc == 6)
		{
			$d7 = $pdf->sec(8, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d7 == 1)
				$d--;
			else if ($d7 == 2)
				$d++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//E Day
	$pdf->SetXY(108, 52.8);
	$inc = 0;
	for ($e = 0; $e < 7; $e++)
	{
		if ($e % 2 == 0)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$e1 = $pdf->sec(4, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e1 == 1)
				$e--;
			else if ($e1 == 2)
				$e++;
		}
		else if ($inc == 1)
		{
			$e2 = $pdf->sec(3, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e2 == 1)
				$e--;
			else if ($e2 == 2)
				$e++;
		}
		else if ($inc == 2)
		{
			$e3 = $pdf->sec(2, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e3 == 1)
				$e--;
			else if ($e3 == 2)
				$e++;
		}
		else if ($inc == 3)
		{
			$e4 = $pdf->sec(1, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e4 == 1)
				$e--;
			else if ($e4 == 2)
				$e++;
		}
		else if ($inc == 4)
		{
			$e5 = $pdf->sec(8, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e5 == 1)
				$e--;
			else if ($e5 == 2)
				$e++;
		}
		else if ($inc == 5)
		{
			$e6 = $pdf->sec(7, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e6 == 1)
				$e--;
			else if ($e6 == 2)
				$e++;
		}
		else if ($inc == 6)
		{
			$e7 = $pdf->sec(6, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e7 == 1)
				$e--;
			else if ($e7 == 2)
				$e++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//F Day
	$pdf->SetXY(127.75, 52.8);
	$inc = 0;
	for ($f = 0; $f < 7; $f++)
	{
		if ($f % 2 == 1)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$f1 = $pdf->sec(3, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f1 == 1)
				$f--;
			else if ($f1 == 2)
				$f++;
		}
		else if ($inc == 1)
		{
			$f2 = $pdf->sec(2, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f2 == 1)
				$f--;
			else if ($f2 == 2)
				$f++;
		}
		else if ($inc == 2)
		{
			$f3 = $pdf->sec(4, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f3 == 1)
				$f--;
			else if ($f3 == 2)
				$f++;
		}
		else if ($inc == 3)
		{
			$f4 = $pdf->sec(6, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f4 == 1)
				$f--;
			else if ($f4 == 2)
				$f++;
		}
		else if ($inc == 4)
		{
			$f5 = $pdf->sec(5, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f5 == 1)
				$f--;
			else if ($f5 == 2)
				$f++;
		}
		else if ($inc == 5)
		{
			$f6 = $pdf->sec(8, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f6 == 1)
				$f--;
			else if ($f6 == 2)
				$f++;
		}
		else if ($inc == 6)
		{
			$f7 = $pdf->sec(7, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f7 == 1)
				$f--;
			else if ($f7 == 2)
				$f++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//G Day
	$pdf->SetXY(147.5, 52.8);
	$inc = 0;
	for ($g = 0; $g < 7; $g++)
	{
		if ($g % 2 == 0)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$g1 = $pdf->sec(2, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g1 == 1)
				$g--;
			else if ($g1 == 2)
				$g++;
		}
		else if ($inc == 1)
		{
			$g2 = $pdf->sec(4, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g2 == 1)
				$g--;
			else if ($g2 == 2)
				$g++;
		}
		else if ($inc == 2)
		{
			$g3 = $pdf->sec(1, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g3 == 1)
				$g--;
			else if ($g3 == 2)
				$g++;
		}
		else if ($inc == 3)
		{
			$g4 = $pdf->sec(3,"G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g4 == 1)
				$g--;
			else if ($g4 == 2)
				$g++;
		}
		else if ($inc == 4)
		{
			$g5 = $pdf->sec(7, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g5 == 1)
				$g--;
			else if ($g5 == 2)
				$g++;
		}
		else if ($inc == 5)
		{
			$g6 = $pdf->sec(5, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g6 == 1)
				$g--;
			else if ($g6 == 2)
				$g++;
		}
		else if ($inc == 6)
		{
			$g7 = $pdf->sec(8, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g7 == 1)
				$g--;
			else if ($g7 == 2)
				$g++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//H Day
	$pdf->SetXY(167.25, 52.8);
	$inc = 0;
	for ($h = 0; $h < 7; $h++)
	{
		if ($h % 2 == 1)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$h1 = $pdf->sec(4, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h1 == 1)
				$h--;
			else if ($h1 == 2)
				$h++;
		}
		else if ($inc == 1)
		{
			$h2 = $pdf->sec(1, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h2 == 1)
				$h--;
			else if ($h2 == 2)
				$h++;
		}
		else if ($inc == 2)
		{
			$h3 = $pdf->sec(2, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h3 == 1)
				$h--;
			else if ($h3 == 2)
				$h++;
		}
		else if ($inc == 3)
		{
			$h4 = $pdf->sec(8, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h4 == 1)
				$h--;
			else if ($h4 == 2)
				$h++;
		}
		else if ($inc == 4)
		{
			$h5 = $pdf->sec(6, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h5 == 1)
				$h--;
			else if ($h5 == 2)
				$h++;
		}
		else if ($inc == 5)
		{
			$h6 = $pdf->sec(7, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h6 == 1)
				$h--;
			else if ($h6 == 2)
				$h++;
		}
		else if ($inc == 6)
		{
			$h7 = $pdf->sec(5, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h7 == 1)
				$h--;
			else if ($h7 == 2)
				$h++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
}	
else if ($_POST['theme'] == "America")
{
	//Create Blocks
	class PDF extends FPDF
	{
		function sec($z, $day, $period, $time1, $time2)
		{
			if ($_POST['sec' . $z . '-free'] == "true")
			{	
				for ($i = 1; $i <= 8; $i++)
				{
					if (substr($_POST['sec' . $i . '-secnum'], 1, 1) == $z)
					{
						if (isset($_POST['sec' . $i . '-doublelabs']))
						{
							foreach($_POST['sec' . $i . '-doublelabs'] as $j)
							{
								if ($day == $j)
									return 1;
							}
						}
						for ($j = 1; $j <= 8; $j++)
						{
							if ($day == $_POST['sec' . $j . '-switchfourth'] AND $period == 4)
							{
								$this->SetFont("Times", '', 6);
								$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
								$this->SetFont("Times", 'B', 6);
								if (strlen($_POST['sec' . $j . '-name']) < 18)
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								else
								{
									$this->SetFont("Times", 'B', 5);
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								}
								$this->SetFont("Times", '', 6);
								if (strlen($_POST['sec' . $j . '-teacher']) < 20)
								{
								$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-teacher'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
								}
								else
								{
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 0, 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								}	
								return;
							}
						}
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
			}
			else
			{
				if (substr($_POST['sec' . $z . '-secnum'], 0, 1) != substr($_POST['sec' . $z . '-secnum'], 1, 1))
				{
					if (isset($_POST['sec' . $z . '-doublelabs']))
					{
						foreach($_POST['sec' . $z . '-doublelabs'] as $i)
						{
							if ($day == $i)
							{
								$this->doublelab($time1, $time2, $z);
								return 2;
							}
						}
					}
					if ($day == $_POST['sec' . $z . '-switchfourth'])
					{
						$this->SetFont("Times", '', 6);
						$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
						$this->SetFont("Times", 'B', 6);
						$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
						return;
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				if (strlen($_POST['sec' . $z . '-name']) < 18)
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				else if (strlen($_POST['sec' . $z . '-name']) < 20)
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				}
				else
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'C', true);
				}
				$this->SetFont("Times", '', 6);
				if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
				{
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
				}
				else
				{
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				}
			}
		}
		public function secX()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 4.5, "-", 'RTL', 2, 'L', true);
			$this->Cell(19.75, 4.5, substr(2000 + $_POST['fyear'] - $_POST['grade'] - 5, 2, 2) . $_POST['grade'] . "-3", 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Advisory - " . $_POST['grade'], 'RL', 2, 'L', true);
			$this->SetFont("Times", '', 6);
			$this->Cell(19.75, 4.5, $_POST['advisor'] . "/" . $_POST['lcounc'], 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Room: " . $_POST['adv-rm'], 'RBL', 2, 'L', true);
		}
		public function secMISC()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 5, "EMPTY", 1, 2, 'C', true);
		}
		function doublelab($time1, $time2, $z)
		{
			//Times
			$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));
		
			$this->SetFont("Times", '', 6);
			for ($i = 0; $i < 7; $i++)
				if ($times[$i][1] == $time2)
				{
					if ($i == 6)
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i][1], 'RTL', 2, 'C', true);
					else
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i + 1][1], 'RTL', 2, 'C', true);
				}	
			$this->SetFont("Times", 'B', 6);
			if (strlen($_POST['sec' . $z . '-name']) < 18)
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			else
			{
				$this->SetFont("Times", 'B', 5);
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			}
			$this->SetFont("Times", '', 6);
			if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
			{
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 33, "", 'RBL', 2, 'L', true);
			}
			else
			{
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 27.5, "", 'RBL', 2, 'L', true);
			}
		}
	}
	
	//Times
	$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));

	//Create PDF
	$pdf = new PDF();

	//Set Page
	$pdf->SetTitle($_POST['fname'] . " " . $_POST['lname'] . "'s Schedule " . $_POST['fyear'] . "-" . $_POST['lyear']);
	$pdf->AddPage();
	$pdf->SetAutoPageBreak(false);
	$pdf->SetMargins(0, 0, 0);
	$pdf->SetFillColor(0, 82, 165);
	$pdf->Rect(0, 0, 210, 297, 'FD');
	$pdf->SetXY(22, 17.5);
	$pdf->SetFillColor(255, 255, 255);
	$pdf->Rect(22, 17.5, 165, 17, 'FD');
	$pdf->SetMargins(22, 17.5, 23);
	$pdf->SetLineWidth(.1);
	$pdf->Rect(88.25, 50, 98.75, 27.5, 'FD');
	$pdf->SetFillColor(224, 22, 43);
	$pdf->Rect(88.25, 80, 98.75, 27.5, 'FD');
	$pdf->SetFillColor(255, 255, 255);
	$pdf->Rect(88.25, 110, 98.75, 27.5, 'FD');
	$pdf->SetFillColor(224, 22, 43);
	$pdf->Rect(29, 140, 158, 27.5, 'FD');
	$pdf->SetFillColor(255, 255, 255);
	$pdf->Rect(29, 165, 158, 27.5, 'FD');
	$pdf->SetFillColor(224, 22, 43);
	$pdf->Rect(29, 195, 158, 27.5, 'FD');
	$pdf->SetFillColor(255, 255, 255);
	$pdf->Rect(29, 220, 158, 27.5, 'FD');
	$pdf->SetFillColor(224, 22, 43);
	$pdf->Rect(29, 245, 158, 27.5, 'FD');

	//Header
	$pdf->SetFillColor(255, 255, 255);
	$pdf->Cell(77, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 4, $_POST['fyear'] . "-" . $_POST['lyear'], 'RL', 0, 'C', true);
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(0, 4, "Student Schedule for " . $_POST['lname'] . ", " . $_POST['fname'] . " " . $_POST['minitial'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 5.66, "Ridgefield High School", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	if (strlen($_POST['studentnum']) == 0)
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Student Number: " . $_POST['studentnum'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	$pdf->Ln();
	$pdf->SetFont("Times", '', 10);
	$pdf->Cell(77, 4, "700 N Salem Rd, Ridgefield CT 06877", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	$pdf->Cell(0, 4, "Term Q1 Q2 Q3 Q4   Courses enrolled: " . $_POST['enrolled'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->Cell(77, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Ln(10);

	//First Line
	$pdf->SetFillColor(218, 165, 32);
	$pdf->SetFont("Times", 'B', 8);
	$pdf->Cell(7, 10, "", 1, 0, 'C', true);
	if ($_POST['semester'] == 1)
	{
		$pdf->Cell(0, 5, "Term Q1 Q2", 1, 2, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5, "Term Q3 Q4", 1, 2, 'C', true);
	}
	$pdf->SetFillColor(0, 82, 165);
	$pdf->Cell(19.75, 5, "A", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "B", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "C", 1, 0, 'C', true);
	$pdf->SetFillColor(224, 22, 43);
	$pdf->Cell(19.75, 5, "D", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "E", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "F", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "G", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "H", 1, 0, 'C', true);
	$pdf->Ln();

	//Periods
	$pdf->SetFillColor(218, 165, 32);
	$pdf->Cell(7, 27.5, "1st", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "2nd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "3rd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "4th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "5th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "6th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "7th", 1, 2, 'C', true);
	$pdf->Cell(7, 22.5, "X", 1, 2, 'C', true);
	$pdf->SetFont("Times", 'B', 7);
	$pdf->Cell(7, 5, "MISC", 1, 0, 'C', true);
	
	//A Day
	$pdf->SetXY(29, 52.8);
	$inc = 0;
	for ($a = 0; $a < 7; $a++)
	{
		if ($a % 2 == 0)
			$pdf->SetFillColor(255, 255, 255);
		else
			$pdf->SetFillColor(224, 22,43);
		if ($a == 0 OR $a == 1 OR $a == 2)
			$pdf->SetFillColor(0, 82, 165);
		if ($inc == 0)
		{
			$a1 = $pdf->sec(1, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a1 == 1)
				$a--;
			else if ($a1 == 2)
				$a++;
		}
		else if ($inc == 1)
		{
			$a2 = $pdf->sec(2, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a2 == 1)
				$a--;
			else if ($a2 == 2)
				$a++;
		}
		else if ($inc == 2)
		{
			$a3 = $pdf->sec(3, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a3 == 1)
				$a--;
			else if ($a3 == 2)
				$a++;
		}
		else if ($inc == 3)
		{
			$a4 = $pdf->sec(4, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a4 == 1)
				$a--;
			else if ($a4 == 2)
				$a++;
		}
		else if ($inc == 4)
		{
			$a5 = $pdf->sec(5, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a5 == 1)
				$a--;
			else if ($a5 == 2)
				$a++;
		}
		else if ($inc == 5)
		{
			$a6 = $pdf->sec(6, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a6 == 1)
				$a--;
			else if ($a6 == 2)
				$a++;
		}
		else if ($inc == 6)
		{
			$a7 = $pdf->sec(7, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a7 == 1)
				$a--;
			else if ($a7 == 2)
				$a++;
		}
		$inc++;
	}
	$pdf->SetFillColor(224, 22, 43);
	$pdf->secX();
	$pdf->secMISC();
	
	//B Day
	$pdf->SetXY(48.75, 52.8);
	$inc = 0;
	for ($b = 0; $b < 7; $b++)
	{
		if ($b % 2 == 0)
			$pdf->SetFillColor(255, 255, 255);
		else
			$pdf->SetFillColor(224, 22,43);
		if ($b == 0 OR $b == 1 OR $b == 2)
			$pdf->SetFillColor(0, 82, 165);
		if ($inc == 0)
		{
			$b1 = $pdf->sec(2, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b1 == 1)
				$b--;
			else if ($b1 == 2)
				$b++;
		}
		else if ($inc == 1)
		{
			$b2 = $pdf->sec(3, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b2 == 1)
				$b--;
			else if ($b2 == 2)
				$b++;
		}
		else if ($inc == 2)
		{
			$b3 = $pdf->sec(1, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b3 == 1)
				$b--;
			else if ($b3 == 2)
				$b++;
		}
		else if ($inc == 3)
		{
			$b4 = $pdf->sec(7, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b4 == 1)
				$b--;
			else if ($b4 == 2)
				$b++;
		}
		else if ($inc == 4)
		{
			$b5 = $pdf->sec(8, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b5 == 1)
				$b--;
			else if ($b5 == 2)
				$b++;
		}
		else if ($inc == 5)
		{
			$b6 = $pdf->sec(5, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b6 == 1)
				$b--;
			else if ($b6 == 2)
				$b++;
		}
		else if ($inc == 6)
		{
			$b7 = $pdf->sec(6, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b7 == 1)
				$b--;
			else if ($b7 == 2)
				$b++;
		}
		$inc++;
	}
	$pdf->SetFillColor(224, 22, 43);
	$pdf->secX();
	$pdf->secMISC();
	
	//C Day
	$pdf->SetXY(68.5, 52.8);
	$inc = 0;
	for ($c = 0; $c < 7; $c++)
	{
		if ($c % 2 == 0)
			$pdf->SetFillColor(255, 255, 255);
		else
			$pdf->SetFillColor(224, 22,43);
		if ($c == 0 OR $c == 1 OR $c == 2)
			$pdf->SetFillColor(0, 82, 165);
		if ($inc == 0)
		{
			$c1 = $pdf->sec(3, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c1 == 1)
				$c--;
			else if ($c1 == 2)
				$c++;
		}
		else if ($inc == 1)
		{
			$c2 = $pdf->sec(1, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c2 == 1)
				$c--;
			else if ($c2 == 2)
				$c++;
		}
		else if ($inc == 2)
		{
			$c3 = $pdf->sec(4, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c3 == 1)
				$c--;
			else if ($c3 == 2)
				$c++;
		}
		else if ($inc == 3)
		{
			$c4 = $pdf->sec(2, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c4 == 1)
				$c--;
			else if ($c4 == 2)
				$c++;
		}
		else if ($inc == 4)
		{
			$c5 = $pdf->sec(6, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c5 == 1)
				$c--;
			else if ($c5 == 2)
				$c++;
		}
		else if ($inc == 5)
		{
			$c6 = $pdf->sec(8, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c6 == 1)
				$c--;
			else if ($c6 == 2)
				$c++;
		}
		else if ($inc == 6)
		{
			$c7 = $pdf->sec(5, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c7 == 1)
				$c--;
			else if ($c7 == 2)
				$c++;
		}
		$inc++;
	}
	$pdf->SetFillColor(224, 22, 43);
	$pdf->secX();
	$pdf->secMISC();
	
	//D Day
	$pdf->SetXY(88.25, 52.8);
	$inc = 0;
	for ($d = 0; $d < 7; $d++)
	{
		if ($d % 2 == 0)
			$pdf->SetFillColor(255, 255, 255);
		else
			$pdf->SetFillColor(224, 22,43);
		if ($inc == 0)
		{
			$d1 = $pdf->sec(1, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d1 == 1)
				$d--;
			else if ($d1 == 2)
				$d++;
		}
		else if ($inc == 1)
		{
			$d2 = $pdf->sec(4, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d2 == 1)
				$d--;
			else if ($d2 == 2)
				$d++;
		}
		else if ($inc == 2)
		{
			$d3 = $pdf->sec(3, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d3 == 1)
				$d--;
			else if ($d3 == 2)
				$d++;
		}
		else if ($inc == 3)
		{
			$d4 = $pdf->sec(5, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d4 == 1)
				$d--;
			else if ($d4 == 2)
				$d++;
		}
		else if ($inc == 4)
		{
			$d5 = $pdf->sec(7, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d5 == 1)
				$d--;
			else if ($d5 == 2)
				$d++;
		}
		else if ($inc == 5)
		{
			$d6 = $pdf->sec(6, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d6 == 1)
				$d--;
			else if ($d6 == 2)
				$d++;
		}
		else if ($inc == 6)
		{
			$d7 = $pdf->sec(8, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d7 == 1)
				$d--;
			else if ($d7 == 2)
				$d++;
		}
		$inc++;
	}
	$pdf->SetFillColor(224, 22, 43);
	$pdf->secX();
	$pdf->secMISC();
	
	//E Day
	$pdf->SetXY(108, 52.8);
	$inc = 0;
	for ($e = 0; $e < 7; $e++)
	{
		if ($e % 2 == 0)
			$pdf->SetFillColor(255, 255, 255);
		else
			$pdf->SetFillColor(224, 22,43);
		if ($inc == 0)
		{
			$e1 = $pdf->sec(4, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e1 == 1)
				$e--;
			else if ($e1 == 2)
				$e++;
		}
		else if ($inc == 1)
		{
			$e2 = $pdf->sec(3, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e2 == 1)
				$e--;
			else if ($e2 == 2)
				$e++;
		}
		else if ($inc == 2)
		{
			$e3 = $pdf->sec(2, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e3 == 1)
				$e--;
			else if ($e3 == 2)
				$e++;
		}
		else if ($inc == 3)
		{
			$e4 = $pdf->sec(1, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e4 == 1)
				$e--;
			else if ($e4 == 2)
				$e++;
		}
		else if ($inc == 4)
		{
			$e5 = $pdf->sec(8, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e5 == 1)
				$e--;
			else if ($e5 == 2)
				$e++;
		}
		else if ($inc == 5)
		{
			$e6 = $pdf->sec(7, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e6 == 1)
				$e--;
			else if ($e6 == 2)
				$e++;
		}
		else if ($inc == 6)
		{
			$e7 = $pdf->sec(6, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e7 == 1)
				$e--;
			else if ($e7 == 2)
				$e++;
		}
		$inc++;
	}
	$pdf->SetFillColor(224, 22, 43);
	$pdf->secX();
	$pdf->secMISC();
	
	//F Day
	$pdf->SetXY(127.75, 52.8);
	$inc = 0;
	for ($f = 0; $f < 7; $f++)
	{
		if ($f % 2 == 0)
			$pdf->SetFillColor(255, 255, 255);
		else
			$pdf->SetFillColor(224, 22,43);
		if ($inc == 0)
		{
			$f1 = $pdf->sec(3, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f1 == 1)
				$f--;
			else if ($f1 == 2)
				$f++;
		}
		else if ($inc == 1)
		{
			$f2 = $pdf->sec(2, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f2 == 1)
				$f--;
			else if ($f2 == 2)
				$f++;
		}
		else if ($inc == 2)
		{
			$f3 = $pdf->sec(4, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f3 == 1)
				$f--;
			else if ($f3 == 2)
				$f++;
		}
		else if ($inc == 3)
		{
			$f4 = $pdf->sec(6, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f4 == 1)
				$f--;
			else if ($f4 == 2)
				$f++;
		}
		else if ($inc == 4)
		{
			$f5 = $pdf->sec(5, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f5 == 1)
				$f--;
			else if ($f5 == 2)
				$f++;
		}
		else if ($inc == 5)
		{
			$f6 = $pdf->sec(8, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f6 == 1)
				$f--;
			else if ($f6 == 2)
				$f++;
		}
		else if ($inc == 6)
		{
			$f7 = $pdf->sec(7, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f7 == 1)
				$f--;
			else if ($f7 == 2)
				$f++;
		}
		$inc++;
	}
	$pdf->SetFillColor(224, 22, 43);
	$pdf->secX();
	$pdf->secMISC();
	
	//G Day
	$pdf->SetXY(147.5, 52.8);
	$inc = 0;
	for ($g = 0; $g < 7; $g++)
	{
		if ($g % 2 == 0)
			$pdf->SetFillColor(255, 255, 255);
		else
			$pdf->SetFillColor(224, 22,43);
		if ($inc == 0)
		{
			$g1 = $pdf->sec(2, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g1 == 1)
				$g--;
			else if ($g1 == 2)
				$g++;
		}
		else if ($inc == 1)
		{
			$g2 = $pdf->sec(4, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g2 == 1)
				$g--;
			else if ($g2 == 2)
				$g++;
		}
		else if ($inc == 2)
		{
			$g3 = $pdf->sec(1, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g3 == 1)
				$g--;
			else if ($g3 == 2)
				$g++;
		}
		else if ($inc == 3)
		{
			$g4 = $pdf->sec(3,"G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g4 == 1)
				$g--;
			else if ($g4 == 2)
				$g++;
		}
		else if ($inc == 4)
		{
			$g5 = $pdf->sec(7, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g5 == 1)
				$g--;
			else if ($g5 == 2)
				$g++;
		}
		else if ($inc == 5)
		{
			$g6 = $pdf->sec(5, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g6 == 1)
				$g--;
			else if ($g6 == 2)
				$g++;
		}
		else if ($inc == 6)
		{
			$g7 = $pdf->sec(8, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g7 == 1)
				$g--;
			else if ($g7 == 2)
				$g++;
		}
		$inc++;
	}
	$pdf->SetFillColor(224, 22, 43);
	$pdf->secX();
	$pdf->secMISC();
	
	//H Day
	$pdf->SetXY(167.25, 52.8);
	$inc = 0;
	for ($h = 0; $h < 7; $h++)
	{
		if ($h % 2 == 0)
			$pdf->SetFillColor(255, 255, 255);
		else
			$pdf->SetFillColor(224, 22,43);
		if ($inc == 0)
		{
			$h1 = $pdf->sec(4, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h1 == 1)
				$h--;
			else if ($h1 == 2)
				$h++;
		}
		else if ($inc == 1)
		{
			$h2 = $pdf->sec(1, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h2 == 1)
				$h--;
			else if ($h2 == 2)
				$h++;
		}
		else if ($inc == 2)
		{
			$h3 = $pdf->sec(2, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h3 == 1)
				$h--;
			else if ($h3 == 2)
				$h++;
		}
		else if ($inc == 3)
		{
			$h4 = $pdf->sec(8, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h4 == 1)
				$h--;
			else if ($h4 == 2)
				$h++;
		}
		else if ($inc == 4)
		{
			$h5 = $pdf->sec(6, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h5 == 1)
				$h--;
			else if ($h5 == 2)
				$h++;
		}
		else if ($inc == 5)
		{
			$h6 = $pdf->sec(7, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h6 == 1)
				$h--;
			else if ($h6 == 2)
				$h++;
		}
		else if ($inc == 6)
		{
			$h7 = $pdf->sec(5, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h7 == 1)
				$h--;
			else if ($h7 == 2)
				$h++;
		}
		$inc++;
	}
	$pdf->SetFillColor(224, 22, 43);
	$pdf->secX();
	$pdf->secMISC();
	
	//Flags
	$pdf->Image("Flags/USAMap.png", 5, 5, 35, 20);
	$pdf->Image("Flags/USAHeart.png", 170, 3, 30, 30);
	$pdf->Image("Flags/USAHeart.png", 3, 265, 30, 30);
	$pdf->Image("Flags/USAMap.png", 170, 270, 35, 20);
}	
else if ($_POST['theme'] == "Cats")
{
	//Create Blocks
	class PDF extends FPDF
	{
		function sec($z, $day, $period, $time1, $time2)
		{
			$this->SetFillColor(255, 255, 255);
			if ($_POST['sec' . $z . '-free'] == "true")
			{	
				for ($i = 1; $i <= 8; $i++)
				{
					if (substr($_POST['sec' . $i . '-secnum'], 1, 1) == $z)
					{
						if (isset($_POST['sec' . $i . '-doublelabs']))
						{
							foreach($_POST['sec' . $i . '-doublelabs'] as $j)
							{
								if ($day == $j)
									return 1;
							}
						}
						for ($j = 1; $j <= 8; $j++)
						{
							if ($day == $_POST['sec' . $j . '-switchfourth'] AND $period == 4)
							{
								$this->SetFont("Times", '', 6);
								$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
								$this->SetFont("Times", 'B', 6);
								if (strlen($_POST['sec' . $j . '-name']) < 18)
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								else
								{
									$this->SetFont("Times", 'B', 5);
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								}
								$this->SetFont("Times", '', 6);
								if (strlen($_POST['sec' . $j . '-teacher']) < 20)
								{
								$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-teacher'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
								}
								else
								{
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 0, 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								}	
								return;
							}
						}
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
			}
			else
			{
				if (substr($_POST['sec' . $z . '-secnum'], 0, 1) != substr($_POST['sec' . $z . '-secnum'], 1, 1))
				{
					if (isset($_POST['sec' . $z . '-doublelabs']))
					{
						foreach($_POST['sec' . $z . '-doublelabs'] as $i)
						{
							if ($day == $i)
							{
								$this->doublelab($time1, $time2, $z);
								return 2;
							}
						}
					}
					if ($day == $_POST['sec' . $z . '-switchfourth'])
					{
						$this->SetFont("Times", '', 6);
						$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
						$this->SetFont("Times", 'B', 6);
						$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
						return;
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				if (strlen($_POST['sec' . $z . '-name']) < 18)
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				else if (strlen($_POST['sec' . $z . '-name']) < 20)
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				}
				else
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'C', true);
				}
				$this->SetFont("Times", '', 6);
				if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
				{
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
				}
				else
				{
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				}
			}
		}
		public function secX()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 4.5, "-", 'RTL', 2, 'L', true);
			$this->Cell(19.75, 4.5, substr(2000 + $_POST['fyear'] - $_POST['grade'] - 5, 2, 2) . $_POST['grade'] . "-3", 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Advisory - " . $_POST['grade'], 'RL', 2, 'L', true);
			$this->SetFont("Times", '', 6);
			$this->Cell(19.75, 4.5, $_POST['advisor'] . "/" . $_POST['lcounc'], 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Room: " . $_POST['adv-rm'], 'RBL', 2, 'L', true);
		}
		public function secMISC()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 5, "EMPTY", 1, 2, 'C', true);
		}
		function doublelab($time1, $time2, $z)
		{
			//Times
			$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));
		
			$this->SetFont("Times", '', 6);
			for ($i = 0; $i < 7; $i++)
				if ($times[$i][1] == $time2)
				{
					if ($i == 6)
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i][1], 'RTL', 2, 'C', true);
					else
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i + 1][1], 'RTL', 2, 'C', true);
				}	
			$this->SetFont("Times", 'B', 6);
			if (strlen($_POST['sec' . $z . '-name']) < 18)
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			else
			{
				$this->SetFont("Times", 'B', 5);
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			}
			$this->SetFont("Times", '', 6);
			if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
			{
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 33, "", 'RBL', 2, 'L', true);
			}
			else
			{
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 27.5, "", 'RBL', 2, 'L', true);
			}
		}
	}
	
	//Times
	$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));

	//Create PDF
	$pdf = new PDF();

	//Set Page
	$pdf->SetTitle($_POST['fname'] . " " . $_POST['lname'] . "'s Schedule " . $_POST['fyear'] . "-" . $_POST['lyear']);
	$pdf->SetMargins(22, 17.5, 23);
	$pdf->SetLineWidth(.1);
	$pdf->AddPage();
	
	//Cats
	$pdf->Image("Cats/PlayfulCat.jpg", 5, 2, 30, 15);
	$pdf->Image("Cats/PlayfulCat2.gif", 40, 2, 30, 15);
	$pdf->Image("Cats/SkinnyCat.jpg", 80, 2, 20, 15);
	$pdf->Image("Cats/BunchesofCats.jpg", 110, 2, 30, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 143, 2, 30, 15);
	$pdf->Image("Cats/TinyCat.jpg", 175, 2, 30, 15);
	$pdf->Image("Cats/TongueCat.jpg", 5, 277.5, 30, 15);
	$pdf->Image("Cats/CreeperCat.jpg", 90,34, 30, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 175, 277.5, 30, 15);
	$pdf->Image("Cats/SkinnyCat.jpg", 40, 277.5, 20, 15);
	$pdf->Image("Cats/PlayfulCat2.gif", 60, 277.5, 30, 15);
	$pdf->Image("Cats/PlayfulCat.jpg", 90, 277.5, 30, 15);
	$pdf->Image("Cats/BunchesofCats.jpg", 120, 277.5, 30, 15);
	$pdf->Image("Cats/TinyCat.jpg", 150, 277.5, 30, 15);
	$pdf->Image("Cats/TongueCat.jpg", 3, 20, 15, 15);
	$pdf->Image("Cats/BoringCat.jpg", 3, 40, 15, 15);
	$pdf->Image("Cats/BunchesofCats2.jpg", 3, 60, 20, 15);
	$pdf->Image("Cats/ConfusedCat.jpg", 3, 80, 15, 15);
	$pdf->Image("Cats/ReachingCat.jpg", 3, 100, 15, 15);
	$pdf->Image("Cats/PoisedCat.jpg", 3, 120, 15, 15);
	$pdf->Image("Cats/NiceCat.jpg", 3, 140, 15, 15);
	$pdf->Image("Cats/PlayfulCat.jpg", 3, 160, 15, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 3, 180, 15, 15);
	$pdf->Image("Cats/TinyCat.jpg", 3, 200, 15, 15);
	$pdf->Image("Cats/TongueCat.jpg", 3, 220, 15, 15);
	$pdf->Image("Cats/CuteCat.jpg", 3, 240, 15, 15);
	$pdf->Image("Cats/StudyingCat.gif", 3, 260, 15, 15);
	$pdf->Image("Cats/FatCat.jpg", 190, 20, 15, 15);
	$pdf->Image("Cats/GrumpyCat.jpg", 190, 40, 15, 15);
	$pdf->Image("Cats/PretentiousCat.jpg", 190, 60, 15, 15);
	$pdf->Image("Cats/SadCats.jpg", 190, 80, 15, 15);
	$pdf->Image("Cats/CuteCat.jpg", 190, 100, 15, 15);
	$pdf->Image("Cats/PoisedCat.jpg", 190, 120, 15, 15);
	$pdf->Image("Cats/SkinnyCat.jpg", 190, 140, 15, 15);
	$pdf->Image("Cats/StudyingCat.gif", 190, 160, 15, 15);
	$pdf->Image("Cats/TinyCat.jpg", 190, 180, 15, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 190, 200, 15, 15);
	$pdf->Image("Cats/StudyingCat.gif", 190, 220, 15, 15);
	$pdf->Image("Cats/PlayfulCat.jpg", 190, 240, 15, 15);
	$pdf->Image("Cats/PretentiousCat.jpg", 190, 260, 15, 15);

	//Header
	$pdf->SetFillColor(255, 255, 255);
	$pdf->Cell(77, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 4, $_POST['fyear'] . "-" . $_POST['lyear'], 'RL', 0, 'C', true);
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(0, 4, "Student Schedule for " . $_POST['lname'] . ", " . $_POST['fname'] . " " . $_POST['minitial'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 5.66, "Ridgefield High School", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	if (strlen($_POST['studentnum']) == 0)
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Student Number: " . $_POST['studentnum'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	$pdf->Ln();
	$pdf->SetFont("Times", '', 10);
	$pdf->Cell(77, 4, "700 N Salem Rd, Ridgefield CT 06877", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	$pdf->Cell(0, 4, "Term Q1 Q2 Q3 Q4   Courses enrolled: " . $_POST['enrolled'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->Cell(77, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Ln(10);

	//First Line
	$pdf->SetFillColor(230, 230, 230);
	$pdf->SetFont("Times", 'B', 8);
	$pdf->Cell(7, 10, "", 1, 0, 'C', true);
	if ($_POST['semester'] == 1)
	{
		$pdf->Cell(0, 5, "Term Q1 Q2", 1, 2, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5, "Term Q3 Q4", 1, 2, 'C', true);
	}
	$pdf->Cell(19.75, 5, "A", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "B", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "C", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "D", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "E", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "F", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "G", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "H", 1, 0, 'C', true);
	$pdf->Ln();

	//Periods
	$pdf->Cell(7, 27.5, "1st", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "2nd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "3rd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "4th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "5th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "6th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "7th", 1, 2, 'C', true);
	$pdf->Cell(7, 22.5, "X", 1, 2, 'C', true);
	$pdf->SetFont("Times", 'B', 7);
	$pdf->Cell(7, 5, "MISC", 1, 0, 'C', true);
	
	//A Day
	$pdf->SetXY(29, 52.8);
	$inc = 0;
	for ($a = 0; $a < 7; $a++)
	{
		if ($inc == 0)
		{
			$a1 = $pdf->sec(1, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a1 == 1)
				$a--;
			else if ($a1 == 2)
				$a++;
		}
		else if ($inc == 1)
		{
			$a2 = $pdf->sec(2, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a2 == 1)
				$a--;
			else if ($a2 == 2)
				$a++;
		}
		else if ($inc == 2)
		{
			$a3 = $pdf->sec(3, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a3 == 1)
				$a--;
			else if ($a3 == 2)
				$a++;
		}
		else if ($inc == 3)
		{
			$a4 = $pdf->sec(4, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a4 == 1)
				$a--;
			else if ($a4 == 2)
				$a++;
		}
		else if ($inc == 4)
		{
			$a5 = $pdf->sec(5, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a5 == 1)
				$a--;
			else if ($a5 == 2)
				$a++;
		}
		else if ($inc == 5)
		{
			$a6 = $pdf->sec(6, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a6 == 1)
				$a--;
			else if ($a6 == 2)
				$a++;
		}
		else if ($inc == 6)
		{
			$a7 = $pdf->sec(7, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a7 == 1)
				$a--;
			else if ($a7 == 2)
				$a++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//B Day
	$pdf->SetXY(48.75, 52.8);
	$inc = 0;
	for ($b = 0; $b < 7; $b++)
	{
		if ($inc == 0)
		{
			$b1 = $pdf->sec(2, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b1 == 1)
				$b--;
			else if ($b1 == 2)
				$b++;
		}
		else if ($inc == 1)
		{
			$b2 = $pdf->sec(3, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b2 == 1)
				$b--;
			else if ($b2 == 2)
				$b++;
		}
		else if ($inc == 2)
		{
			$b3 = $pdf->sec(1, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b3 == 1)
				$b--;
			else if ($b3 == 2)
				$b++;
		}
		else if ($inc == 3)
		{
			$b4 = $pdf->sec(7, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b4 == 1)
				$b--;
			else if ($b4 == 2)
				$b++;
		}
		else if ($inc == 4)
		{
			$b5 = $pdf->sec(8, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b5 == 1)
				$b--;
			else if ($b5 == 2)
				$b++;
		}
		else if ($inc == 5)
		{
			$b6 = $pdf->sec(5, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b6 == 1)
				$b--;
			else if ($b6 == 2)
				$b++;
		}
		else if ($inc == 6)
		{
			$b7 = $pdf->sec(6, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b7 == 1)
				$b--;
			else if ($b7 == 2)
				$b++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//C Day
	$pdf->SetXY(68.5, 52.8);
	$inc = 0;
	for ($c = 0; $c < 7; $c++)
	{
		if ($inc == 0)
		{
			$c1 = $pdf->sec(3, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c1 == 1)
				$c--;
			else if ($c1 == 2)
				$c++;
		}
		else if ($inc == 1)
		{
			$c2 = $pdf->sec(1, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c2 == 1)
				$c--;
			else if ($c2 == 2)
				$c++;
		}
		else if ($inc == 2)
		{
			$c3 = $pdf->sec(4, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c3 == 1)
				$c--;
			else if ($c3 == 2)
				$c++;
		}
		else if ($inc == 3)
		{
			$c4 = $pdf->sec(2, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c4 == 1)
				$c--;
			else if ($c4 == 2)
				$c++;
		}
		else if ($inc == 4)
		{
			$c5 = $pdf->sec(6, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c5 == 1)
				$c--;
			else if ($c5 == 2)
				$c++;
		}
		else if ($inc == 5)
		{
			$c6 = $pdf->sec(8, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c6 == 1)
				$c--;
			else if ($c6 == 2)
				$c++;
		}
		else if ($inc == 6)
		{
			$c7 = $pdf->sec(5, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c7 == 1)
				$c--;
			else if ($c7 == 2)
				$c++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//D Day
	$pdf->SetXY(88.25, 52.8);
	$inc = 0;
	for ($d = 0; $d < 7; $d++)
	{
		if ($inc == 0)
		{
			$d1 = $pdf->sec(1, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d1 == 1)
				$d--;
			else if ($d1 == 2)
				$d++;
		}
		else if ($inc == 1)
		{
			$d2 = $pdf->sec(4, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d2 == 1)
				$d--;
			else if ($d2 == 2)
				$d++;
		}
		else if ($inc == 2)
		{
			$d3 = $pdf->sec(3, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d3 == 1)
				$d--;
			else if ($d3 == 2)
				$d++;
		}
		else if ($inc == 3)
		{
			$d4 = $pdf->sec(5, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d4 == 1)
				$d--;
			else if ($d4 == 2)
				$d++;
		}
		else if ($inc == 4)
		{
			$d5 = $pdf->sec(7, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d5 == 1)
				$d--;
			else if ($d5 == 2)
				$d++;
		}
		else if ($inc == 5)
		{
			$d6 = $pdf->sec(6, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d6 == 1)
				$d--;
			else if ($d6 == 2)
				$d++;
		}
		else if ($inc == 6)
		{
			$d7 = $pdf->sec(8, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d7 == 1)
				$d--;
			else if ($d7 == 2)
				$d++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//E Day
	$pdf->SetXY(108, 52.8);
	$inc = 0;
	for ($e = 0; $e < 7; $e++)
	{
		if ($inc == 0)
		{
			$e1 = $pdf->sec(4, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e1 == 1)
				$e--;
			else if ($e1 == 2)
				$e++;
		}
		else if ($inc == 1)
		{
			$e2 = $pdf->sec(3, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e2 == 1)
				$e--;
			else if ($e2 == 2)
				$e++;
		}
		else if ($inc == 2)
		{
			$e3 = $pdf->sec(2, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e3 == 1)
				$e--;
			else if ($e3 == 2)
				$e++;
		}
		else if ($inc == 3)
		{
			$e4 = $pdf->sec(1, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e4 == 1)
				$e--;
			else if ($e4 == 2)
				$e++;
		}
		else if ($inc == 4)
		{
			$e5 = $pdf->sec(8, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e5 == 1)
				$e--;
			else if ($e5 == 2)
				$e++;
		}
		else if ($inc == 5)
		{
			$e6 = $pdf->sec(7, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e6 == 1)
				$e--;
			else if ($e6 == 2)
				$e++;
		}
		else if ($inc == 6)
		{
			$e7 = $pdf->sec(6, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e7 == 1)
				$e--;
			else if ($e7 == 2)
				$e++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//F Day
	$pdf->SetXY(127.75, 52.8);
	$inc = 0;
	for ($f = 0; $f < 7; $f++)
	{
		if ($inc == 0)
		{
			$f1 = $pdf->sec(3, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f1 == 1)
				$f--;
			else if ($f1 == 2)
				$f++;
		}
		else if ($inc == 1)
		{
			$f2 = $pdf->sec(2, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f2 == 1)
				$f--;
			else if ($f2 == 2)
				$f++;
		}
		else if ($inc == 2)
		{
			$f3 = $pdf->sec(4, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f3 == 1)
				$f--;
			else if ($f3 == 2)
				$f++;
		}
		else if ($inc == 3)
		{
			$f4 = $pdf->sec(6, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f4 == 1)
				$f--;
			else if ($f4 == 2)
				$f++;
		}
		else if ($inc == 4)
		{
			$f5 = $pdf->sec(5, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f5 == 1)
				$f--;
			else if ($f5 == 2)
				$f++;
		}
		else if ($inc == 5)
		{
			$f6 = $pdf->sec(8, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f6 == 1)
				$f--;
			else if ($f6 == 2)
				$f++;
		}
		else if ($inc == 6)
		{
			$f7 = $pdf->sec(7, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f7 == 1)
				$f--;
			else if ($f7 == 2)
				$f++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//G Day
	$pdf->SetXY(147.5, 52.8);
	$inc = 0;
	for ($g = 0; $g < 7; $g++)
	{
		if ($inc == 0)
		{
			$g1 = $pdf->sec(2, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g1 == 1)
				$g--;
			else if ($g1 == 2)
				$g++;
		}
		else if ($inc == 1)
		{
			$g2 = $pdf->sec(4, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g2 == 1)
				$g--;
			else if ($g2 == 2)
				$g++;
		}
		else if ($inc == 2)
		{
			$g3 = $pdf->sec(1, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g3 == 1)
				$g--;
			else if ($g3 == 2)
				$g++;
		}
		else if ($inc == 3)
		{
			$g4 = $pdf->sec(3,"G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g4 == 1)
				$g--;
			else if ($g4 == 2)
				$g++;
		}
		else if ($inc == 4)
		{
			$g5 = $pdf->sec(7, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g5 == 1)
				$g--;
			else if ($g5 == 2)
				$g++;
		}
		else if ($inc == 5)
		{
			$g6 = $pdf->sec(5, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g6 == 1)
				$g--;
			else if ($g6 == 2)
				$g++;
		}
		else if ($inc == 6)
		{
			$g7 = $pdf->sec(8, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g7 == 1)
				$g--;
			else if ($g7 == 2)
				$g++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//H Day
	$pdf->SetXY(167.25, 52.8);
	$inc = 0;
	for ($h = 0; $h < 7; $h++)
	{
		if ($inc == 0)
		{
			$h1 = $pdf->sec(4, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h1 == 1)
				$h--;
			else if ($h1 == 2)
				$h++;
		}
		else if ($inc == 1)
		{
			$h2 = $pdf->sec(1, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h2 == 1)
				$h--;
			else if ($h2 == 2)
				$h++;
		}
		else if ($inc == 2)
		{
			$h3 = $pdf->sec(2, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h3 == 1)
				$h--;
			else if ($h3 == 2)
				$h++;
		}
		else if ($inc == 3)
		{
			$h4 = $pdf->sec(8, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h4 == 1)
				$h--;
			else if ($h4 == 2)
				$h++;
		}
		else if ($inc == 4)
		{
			$h5 = $pdf->sec(6, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h5 == 1)
				$h--;
			else if ($h5 == 2)
				$h++;
		}
		else if ($inc == 5)
		{
			$h6 = $pdf->sec(7, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h6 == 1)
				$h--;
			else if ($h6 == 2)
				$h++;
		}
		else if ($inc == 6)
		{
			$h7 = $pdf->sec(5, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h7 == 1)
				$h--;
			else if ($h7 == 2)
				$h++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
}
else if ($_POST['theme'] == "ColoredCats")
{
	//Create Blocks
	class PDF extends FPDF
	{
		function sec($z, $day, $period, $time1, $time2)
		{
			if ($z == 1)
				$this->SetFillColor(176, 223, 229);
			else if ($z == 2)
				$this->SetFillColor(255, 77, 77);
			else if ($z == 3)
				$this->SetFillColor(254, 218, 186);
			else if ($z == 4)
				$this->SetFillColor(254, 215, 0);
			else if ($z == 5)
				$this->SetFillColor(148, 112, 220);
			else if ($z == 6)
				$this->SetFillColor(144, 238, 144);
			else if ($z == 7)
				$this->SetFillColor(255, 153, 255);
			else if ($z == 8)
				$this->SetFillColor(252, 228, 133);
			if ($_POST['sec' . $z . '-free'] == "true")
			{	
				for ($i = 1; $i <= 8; $i++)
				{
					if (substr($_POST['sec' . $i . '-secnum'], 1, 1) == $z)
					{
						if (isset($_POST['sec' . $i . '-doublelabs']))
						{
							foreach($_POST['sec' . $i . '-doublelabs'] as $j)
							{
								if ($day == $j)
									return 1;
							}
						}
						for ($j = 1; $j <= 8; $j++)
						{
							if ($day == $_POST['sec' . $j . '-switchfourth'] AND $period == 4)
							{
								if ($j == 1)
									$this->SetFillColor(176, 223, 229);
								else if ($j == 2)
									$this->SetFillColor(255, 77, 77);
								else if ($j == 3)
									$this->SetFillColor(254, 218, 186);
								else if ($j == 4)
									$this->SetFillColor(254, 215, 0);
								else if ($j == 5)
									$this->SetFillColor(148, 112, 220);
								else if ($j == 6)
									$this->SetFillColor(144, 238, 144);
								else if ($j == 7)
									$this->SetFillColor(255, 153, 255);
								else if ($j == 8)
									$this->SetFillColor(252, 228, 133);
								$this->SetFont("Times", '', 6);
								$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
								$this->SetFont("Times", 'B', 6);
								if (strlen($_POST['sec' . $j . '-name']) < 18)
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								else
								{
									$this->SetFont("Times", 'B', 5);
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								}
								$this->SetFont("Times", '', 6);
								if (strlen($_POST['sec' . $j . '-teacher']) < 20)
								{
								$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-teacher'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
								}
								else
								{
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 0, 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								}	
								return;
							}
						}
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
			}
			else
			{
				if (substr($_POST['sec' . $z . '-secnum'], 0, 1) != substr($_POST['sec' . $z . '-secnum'], 1, 1))
				{
					if (isset($_POST['sec' . $z . '-doublelabs']))
					{
						foreach($_POST['sec' . $z . '-doublelabs'] as $i)
						{
							if ($day == $i)
							{
								$this->doublelab($time1, $time2, $z);
								return 2;
							}
						}
					}
					if ($day == $_POST['sec' . $z . '-switchfourth'])
					{
						if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 1)
							$this->SetFillColor(176, 223, 229);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 2)
							$this->SetFillColor(255, 77, 77);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 3)
							$this->SetFillColor(254, 218, 186);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 4)
							$this->SetFillColor(254, 215, 0);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 5)
							$this->SetFillColor(148, 112, 220);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 6)
							$this->SetFillColor(144, 238, 144);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 7)
							$this->SetFillColor(255, 153, 255);
						else if (substr($_POST['sec' . $z . "-secnum"], 1, 1) == 8)
							$this->SetFillColor(252, 228, 133);
						$this->SetFont("Times", '', 6);
						$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
						$this->SetFont("Times", 'B', 6);
						$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
						return;
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				if (strlen($_POST['sec' . $z . '-name']) < 18)
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				else if (strlen($_POST['sec' . $z . '-name']) < 20)
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				}
				else
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'C', true);
				}
				$this->SetFont("Times", '', 6);
				if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
				{
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
				}
				else
				{
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				}
			}
		}
		public function secX()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 4.5, "-", 'RTL', 2, 'L', true);
			$this->Cell(19.75, 4.5, substr(2000 + $_POST['fyear'] - $_POST['grade'] - 5, 2, 2) . $_POST['grade'] . "-3", 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Advisory - " . $_POST['grade'], 'RL', 2, 'L', true);
			$this->SetFont("Times", '', 6);
			$this->Cell(19.75, 4.5, $_POST['advisor'] . "/" . $_POST['lcounc'], 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Room: " . $_POST['adv-rm'], 'RBL', 2, 'L', true);
		}
		public function secMISC()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 5, "EMPTY", 1, 2, 'C', true);
		}
		function doublelab($time1, $time2, $z)
		{
			//Times
			$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));
		
			$this->SetFont("Times", '', 6);
			for ($i = 0; $i < 7; $i++)
				if ($times[$i][1] == $time2)
				{
					if ($i == 6)
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i][1], 'RTL', 2, 'C', true);
					else
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i + 1][1], 'RTL', 2, 'C', true);
				}	
			$this->SetFont("Times", 'B', 6);
			if (strlen($_POST['sec' . $z . '-name']) < 18)
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			else
			{
				$this->SetFont("Times", 'B', 5);
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			}
			$this->SetFont("Times", '', 6);
			if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
			{
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 33, "", 'RBL', 2, 'L', true);
			}
			else
			{
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 27.5, "", 'RBL', 2, 'L', true);
			}
		}
	}
	
	//Times
	$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));

	//Create PDF
	$pdf = new PDF();

	//Set Page
	$pdf->SetTitle($_POST['fname'] . " " . $_POST['lname'] . "'s Schedule " . $_POST['fyear'] . "-" . $_POST['lyear']);
	$pdf->SetMargins(22, 17.5, 23);
	$pdf->SetLineWidth(.1);
	$pdf->AddPage();
	
	//Cats
	$pdf->Image("Cats/PlayfulCat.jpg", 5, 2, 30, 15);
	$pdf->Image("Cats/PlayfulCat2.gif", 40, 2, 30, 15);
	$pdf->Image("Cats/SkinnyCat.jpg", 80, 2, 20, 15);
	$pdf->Image("Cats/BunchesofCats.jpg", 110, 2, 30, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 143, 2, 30, 15);
	$pdf->Image("Cats/TinyCat.jpg", 175, 2, 30, 15);
	$pdf->Image("Cats/TongueCat.jpg", 5, 277.5, 30, 15);
	$pdf->Image("Cats/CreeperCat.jpg", 90,34, 30, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 175, 277.5, 30, 15);
	$pdf->Image("Cats/SkinnyCat.jpg", 40, 277.5, 20, 15);
	$pdf->Image("Cats/PlayfulCat2.gif", 60, 277.5, 30, 15);
	$pdf->Image("Cats/PlayfulCat.jpg", 90, 277.5, 30, 15);
	$pdf->Image("Cats/BunchesofCats.jpg", 120, 277.5, 30, 15);
	$pdf->Image("Cats/TinyCat.jpg", 150, 277.5, 30, 15);
	$pdf->Image("Cats/TongueCat.jpg", 3, 20, 15, 15);
	$pdf->Image("Cats/BoringCat.jpg", 3, 40, 15, 15);
	$pdf->Image("Cats/BunchesofCats2.jpg", 3, 60, 20, 15);
	$pdf->Image("Cats/ConfusedCat.jpg", 3, 80, 15, 15);
	$pdf->Image("Cats/ReachingCat.jpg", 3, 100, 15, 15);
	$pdf->Image("Cats/PoisedCat.jpg", 3, 120, 15, 15);
	$pdf->Image("Cats/NiceCat.jpg", 3, 140, 15, 15);
	$pdf->Image("Cats/PlayfulCat.jpg", 3, 160, 15, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 3, 180, 15, 15);
	$pdf->Image("Cats/TinyCat.jpg", 3, 200, 15, 15);
	$pdf->Image("Cats/TongueCat.jpg", 3, 220, 15, 15);
	$pdf->Image("Cats/CuteCat.jpg", 3, 240, 15, 15);
	$pdf->Image("Cats/StudyingCat.gif", 3, 260, 15, 15);
	$pdf->Image("Cats/FatCat.jpg", 190, 20, 15, 15);
	$pdf->Image("Cats/GrumpyCat.jpg", 190, 40, 15, 15);
	$pdf->Image("Cats/PretentiousCat.jpg", 190, 60, 15, 15);
	$pdf->Image("Cats/SadCats.jpg", 190, 80, 15, 15);
	$pdf->Image("Cats/CuteCat.jpg", 190, 100, 15, 15);
	$pdf->Image("Cats/PoisedCat.jpg", 190, 120, 15, 15);
	$pdf->Image("Cats/SkinnyCat.jpg", 190, 140, 15, 15);
	$pdf->Image("Cats/StudyingCat.gif", 190, 160, 15, 15);
	$pdf->Image("Cats/TinyCat.jpg", 190, 180, 15, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 190, 200, 15, 15);
	$pdf->Image("Cats/StudyingCat.gif", 190, 220, 15, 15);
	$pdf->Image("Cats/PlayfulCat.jpg", 190, 240, 15, 15);
	$pdf->Image("Cats/PretentiousCat.jpg", 190, 260, 15, 15);

	//Header
	$pdf->SetFillColor(255, 255, 255);
	$pdf->Cell(77, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 4, $_POST['fyear'] . "-" . $_POST['lyear'], 'RL', 0, 'C', true);
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(0, 4, "Student Schedule for " . $_POST['lname'] . ", " . $_POST['fname'] . " " . $_POST['minitial'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 5.66, "Ridgefield High School", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	if (strlen($_POST['studentnum']) == 0)
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Student Number: " . $_POST['studentnum'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	$pdf->Ln();
	$pdf->SetFont("Times", '', 10);
	$pdf->Cell(77, 4, "700 N Salem Rd, Ridgefield CT 06877", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	$pdf->Cell(0, 4, "Term Q1 Q2 Q3 Q4   Courses enrolled: " . $_POST['enrolled'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->Cell(77, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Ln(10);

	//First Line
	$pdf->SetFillColor(230, 230, 230);
	$pdf->SetFont("Times", 'B', 8);
	$pdf->Cell(7, 10, "", 1, 0, 'C', true);
	if ($_POST['semester'] == 1)
	{
		$pdf->Cell(0, 5, "Term Q1 Q2", 1, 2, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5, "Term Q3 Q4", 1, 2, 'C', true);
	}
	$pdf->Cell(19.75, 5, "A", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "B", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "C", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "D", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "E", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "F", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "G", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "H", 1, 0, 'C', true);
	$pdf->Ln();

	//Periods
	$pdf->Cell(7, 27.5, "1st", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "2nd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "3rd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "4th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "5th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "6th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "7th", 1, 2, 'C', true);
	$pdf->Cell(7, 22.5, "X", 1, 2, 'C', true);
	$pdf->SetFont("Times", 'B', 7);
	$pdf->Cell(7, 5, "MISC", 1, 0, 'C', true);
	
	//A Day
	$pdf->SetXY(29, 52.8);
	$inc = 0;
	for ($a = 0; $a < 7; $a++)
	{
		if ($inc == 0)
		{
			$a1 = $pdf->sec(1, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a1 == 1)
				$a--;
			else if ($a1 == 2)
				$a++;
		}
		else if ($inc == 1)
		{
			$a2 = $pdf->sec(2, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a2 == 1)
				$a--;
			else if ($a2 == 2)
				$a++;
		}
		else if ($inc == 2)
		{
			$a3 = $pdf->sec(3, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a3 == 1)
				$a--;
			else if ($a3 == 2)
				$a++;
		}
		else if ($inc == 3)
		{
			$a4 = $pdf->sec(4, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a4 == 1)
				$a--;
			else if ($a4 == 2)
				$a++;
		}
		else if ($inc == 4)
		{
			$a5 = $pdf->sec(5, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a5 == 1)
				$a--;
			else if ($a5 == 2)
				$a++;
		}
		else if ($inc == 5)
		{
			$a6 = $pdf->sec(6, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a6 == 1)
				$a--;
			else if ($a6 == 2)
				$a++;
		}
		else if ($inc == 6)
		{
			$a7 = $pdf->sec(7, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a7 == 1)
				$a--;
			else if ($a7 == 2)
				$a++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//B Day
	$pdf->SetXY(48.75, 52.8);
	$inc = 0;
	for ($b = 0; $b < 7; $b++)
	{
		if ($inc == 0)
		{
			$b1 = $pdf->sec(2, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b1 == 1)
				$b--;
			else if ($b1 == 2)
				$b++;
		}
		else if ($inc == 1)
		{
			$b2 = $pdf->sec(3, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b2 == 1)
				$b--;
			else if ($b2 == 2)
				$b++;
		}
		else if ($inc == 2)
		{
			$b3 = $pdf->sec(1, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b3 == 1)
				$b--;
			else if ($b3 == 2)
				$b++;
		}
		else if ($inc == 3)
		{
			$b4 = $pdf->sec(7, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b4 == 1)
				$b--;
			else if ($b4 == 2)
				$b++;
		}
		else if ($inc == 4)
		{
			$b5 = $pdf->sec(8, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b5 == 1)
				$b--;
			else if ($b5 == 2)
				$b++;
		}
		else if ($inc == 5)
		{
			$b6 = $pdf->sec(5, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b6 == 1)
				$b--;
			else if ($b6 == 2)
				$b++;
		}
		else if ($inc == 6)
		{
			$b7 = $pdf->sec(6, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b7 == 1)
				$b--;
			else if ($b7 == 2)
				$b++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//C Day
	$pdf->SetXY(68.5, 52.8);
	$inc = 0;
	for ($c = 0; $c < 7; $c++)
	{
		if ($inc == 0)
		{
			$c1 = $pdf->sec(3, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c1 == 1)
				$c--;
			else if ($c1 == 2)
				$c++;
		}
		else if ($inc == 1)
		{
			$c2 = $pdf->sec(1, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c2 == 1)
				$c--;
			else if ($c2 == 2)
				$c++;
		}
		else if ($inc == 2)
		{
			$c3 = $pdf->sec(4, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c3 == 1)
				$c--;
			else if ($c3 == 2)
				$c++;
		}
		else if ($inc == 3)
		{
			$c4 = $pdf->sec(2, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c4 == 1)
				$c--;
			else if ($c4 == 2)
				$c++;
		}
		else if ($inc == 4)
		{
			$c5 = $pdf->sec(6, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c5 == 1)
				$c--;
			else if ($c5 == 2)
				$c++;
		}
		else if ($inc == 5)
		{
			$c6 = $pdf->sec(8, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c6 == 1)
				$c--;
			else if ($c6 == 2)
				$c++;
		}
		else if ($inc == 6)
		{
			$c7 = $pdf->sec(5, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c7 == 1)
				$c--;
			else if ($c7 == 2)
				$c++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//D Day
	$pdf->SetXY(88.25, 52.8);
	$inc = 0;
	for ($d = 0; $d < 7; $d++)
	{
		if ($inc == 0)
		{
			$d1 = $pdf->sec(1, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d1 == 1)
				$d--;
			else if ($d1 == 2)
				$d++;
		}
		else if ($inc == 1)
		{
			$d2 = $pdf->sec(4, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d2 == 1)
				$d--;
			else if ($d2 == 2)
				$d++;
		}
		else if ($inc == 2)
		{
			$d3 = $pdf->sec(3, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d3 == 1)
				$d--;
			else if ($d3 == 2)
				$d++;
		}
		else if ($inc == 3)
		{
			$d4 = $pdf->sec(5, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d4 == 1)
				$d--;
			else if ($d4 == 2)
				$d++;
		}
		else if ($inc == 4)
		{
			$d5 = $pdf->sec(7, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d5 == 1)
				$d--;
			else if ($d5 == 2)
				$d++;
		}
		else if ($inc == 5)
		{
			$d6 = $pdf->sec(6, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d6 == 1)
				$d--;
			else if ($d6 == 2)
				$d++;
		}
		else if ($inc == 6)
		{
			$d7 = $pdf->sec(8, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d7 == 1)
				$d--;
			else if ($d7 == 2)
				$d++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//E Day
	$pdf->SetXY(108, 52.8);
	$inc = 0;
	for ($e = 0; $e < 7; $e++)
	{
		if ($inc == 0)
		{
			$e1 = $pdf->sec(4, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e1 == 1)
				$e--;
			else if ($e1 == 2)
				$e++;
		}
		else if ($inc == 1)
		{
			$e2 = $pdf->sec(3, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e2 == 1)
				$e--;
			else if ($e2 == 2)
				$e++;
		}
		else if ($inc == 2)
		{
			$e3 = $pdf->sec(2, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e3 == 1)
				$e--;
			else if ($e3 == 2)
				$e++;
		}
		else if ($inc == 3)
		{
			$e4 = $pdf->sec(1, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e4 == 1)
				$e--;
			else if ($e4 == 2)
				$e++;
		}
		else if ($inc == 4)
		{
			$e5 = $pdf->sec(8, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e5 == 1)
				$e--;
			else if ($e5 == 2)
				$e++;
		}
		else if ($inc == 5)
		{
			$e6 = $pdf->sec(7, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e6 == 1)
				$e--;
			else if ($e6 == 2)
				$e++;
		}
		else if ($inc == 6)
		{
			$e7 = $pdf->sec(6, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e7 == 1)
				$e--;
			else if ($e7 == 2)
				$e++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//F Day
	$pdf->SetXY(127.75, 52.8);
	$inc = 0;
	for ($f = 0; $f < 7; $f++)
	{
		if ($inc == 0)
		{
			$f1 = $pdf->sec(3, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f1 == 1)
				$f--;
			else if ($f1 == 2)
				$f++;
		}
		else if ($inc == 1)
		{
			$f2 = $pdf->sec(2, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f2 == 1)
				$f--;
			else if ($f2 == 2)
				$f++;
		}
		else if ($inc == 2)
		{
			$f3 = $pdf->sec(4, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f3 == 1)
				$f--;
			else if ($f3 == 2)
				$f++;
		}
		else if ($inc == 3)
		{
			$f4 = $pdf->sec(6, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f4 == 1)
				$f--;
			else if ($f4 == 2)
				$f++;
		}
		else if ($inc == 4)
		{
			$f5 = $pdf->sec(5, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f5 == 1)
				$f--;
			else if ($f5 == 2)
				$f++;
		}
		else if ($inc == 5)
		{
			$f6 = $pdf->sec(8, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f6 == 1)
				$f--;
			else if ($f6 == 2)
				$f++;
		}
		else if ($inc == 6)
		{
			$f7 = $pdf->sec(7, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f7 == 1)
				$f--;
			else if ($f7 == 2)
				$f++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//G Day
	$pdf->SetXY(147.5, 52.8);
	$inc = 0;
	for ($g = 0; $g < 7; $g++)
	{
		if ($inc == 0)
		{
			$g1 = $pdf->sec(2, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g1 == 1)
				$g--;
			else if ($g1 == 2)
				$g++;
		}
		else if ($inc == 1)
		{
			$g2 = $pdf->sec(4, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g2 == 1)
				$g--;
			else if ($g2 == 2)
				$g++;
		}
		else if ($inc == 2)
		{
			$g3 = $pdf->sec(1, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g3 == 1)
				$g--;
			else if ($g3 == 2)
				$g++;
		}
		else if ($inc == 3)
		{
			$g4 = $pdf->sec(3,"G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g4 == 1)
				$g--;
			else if ($g4 == 2)
				$g++;
		}
		else if ($inc == 4)
		{
			$g5 = $pdf->sec(7, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g5 == 1)
				$g--;
			else if ($g5 == 2)
				$g++;
		}
		else if ($inc == 5)
		{
			$g6 = $pdf->sec(5, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g6 == 1)
				$g--;
			else if ($g6 == 2)
				$g++;
		}
		else if ($inc == 6)
		{
			$g7 = $pdf->sec(8, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g7 == 1)
				$g--;
			else if ($g7 == 2)
				$g++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
	
	//H Day
	$pdf->SetXY(167.25, 52.8);
	$inc = 0;
	for ($h = 0; $h < 7; $h++)
	{
		if ($inc == 0)
		{
			$h1 = $pdf->sec(4, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h1 == 1)
				$h--;
			else if ($h1 == 2)
				$h++;
		}
		else if ($inc == 1)
		{
			$h2 = $pdf->sec(1, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h2 == 1)
				$h--;
			else if ($h2 == 2)
				$h++;
		}
		else if ($inc == 2)
		{
			$h3 = $pdf->sec(2, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h3 == 1)
				$h--;
			else if ($h3 == 2)
				$h++;
		}
		else if ($inc == 3)
		{
			$h4 = $pdf->sec(8, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h4 == 1)
				$h--;
			else if ($h4 == 2)
				$h++;
		}
		else if ($inc == 4)
		{
			$h5 = $pdf->sec(6, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h5 == 1)
				$h--;
			else if ($h5 == 2)
				$h++;
		}
		else if ($inc == 5)
		{
			$h6 = $pdf->sec(7, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h6 == 1)
				$h--;
			else if ($h6 == 2)
				$h++;
		}
		else if ($inc == 6)
		{
			$h7 = $pdf->sec(5, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h7 == 1)
				$h--;
			else if ($h7 == 2)
				$h++;
		}
		$inc++;
	}
	$pdf->SetFillColor(230, 230, 230);
	$pdf->secX();
	$pdf->secMISC();
}
else if ($_POST['theme'] == "RHSCats")
{
	//Create Blocks
	class PDF extends FPDF
	{
		function sec($z, $day, $period, $time1, $time2)
		{
			if ($_POST['sec' . $z . '-free'] == "true")
			{	
				for ($i = 1; $i <= 8; $i++)
				{
					if (substr($_POST['sec' . $i . '-secnum'], 1, 1) == $z)
					{
						if (isset($_POST['sec' . $i . '-doublelabs']))
						{
							foreach($_POST['sec' . $i . '-doublelabs'] as $j)
							{
								if ($day == $j)
									return 1;
							}
						}
						for ($j = 1; $j <= 8; $j++)
						{
							if ($day == $_POST['sec' . $j . '-switchfourth'] AND $period == 4)
							{
								$this->SetFont("Times", '', 6);
								$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
								$this->SetFont("Times", 'B', 6);
								if (strlen($_POST['sec' . $j . '-name']) < 18)
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								else
								{
									$this->SetFont("Times", 'B', 5);
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								}
								$this->SetFont("Times", '', 6);
								if (strlen($_POST['sec' . $j . '-teacher']) < 20)
								{
								$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-teacher'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
								}
								else
								{
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 0, 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								}	
								return;
							}
						}
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
			}
			else
			{
				if (substr($_POST['sec' . $z . '-secnum'], 0, 1) != substr($_POST['sec' . $z . '-secnum'], 1, 1))
				{
					if (isset($_POST['sec' . $z . '-doublelabs']))
					{
						foreach($_POST['sec' . $z . '-doublelabs'] as $i)
						{
							if ($day == $i)
							{
								$this->doublelab($time1, $time2, $z);
								return 2;
							}
						}
					}
					if ($day == $_POST['sec' . $z . '-switchfourth'])
					{
						$this->SetFont("Times", '', 6);
						$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
						$this->SetFont("Times", 'B', 6);
						$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
						return;
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				if (strlen($_POST['sec' . $z . '-name']) < 18)
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				else if (strlen($_POST['sec' . $z . '-name']) < 20)
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				}
				else
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'C', true);
				}
				$this->SetFont("Times", '', 6);
				if (strlen($_POST['sec' . $z . '-teacher']) < 21)
				{
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
				}
				else
				{
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 21), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 21), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				}
			}
		}
		public function secX()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 4.5, "-", 'RTL', 2, 'L', true);
			$this->Cell(19.75, 4.5, substr(2000 + $_POST['fyear'] - $_POST['grade'] - 5, 2, 2) . $_POST['grade'] . "-3", 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Advisory - " . $_POST['grade'], 'RL', 2, 'L', true);
			$this->SetFont("Times", '', 6);
			$this->Cell(19.75, 4.5, $_POST['advisor'] . "/" . $_POST['lcounc'], 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Room: " . $_POST['adv-rm'], 'RBL', 2, 'L', true);
		}
		public function secMISC()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 5, "EMPTY", 1, 2, 'C', true);
		}
		function doublelab($time1, $time2, $z)
		{
			//Times
			$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));
		
			$this->SetFont("Times", '', 6);
			for ($i = 0; $i < 7; $i++)
				if ($times[$i][1] == $time2)
				{
					if ($i == 6)
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i][1], 'RTL', 2, 'C', true);
					else
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i + 1][1], 'RTL', 2, 'C', true);
				}	
			$this->SetFont("Times", 'B', 6);
			if (strlen($_POST['sec' . $z . '-name']) < 18)
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			else
			{
				$this->SetFont("Times", 'B', 5);
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			}
			$this->SetFont("Times", '', 6);
			if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
			{
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 33, "", 'RBL', 2, 'L', true);
			}
			else
			{
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 27.5, "", 'RBL', 2, 'L', true);
			}
		}
	}
	
	//Times
	$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));

	//Create PDF
	$pdf = new PDF();

	//Set Page
	$pdf->SetTitle($_POST['fname'] . " " . $_POST['lname'] . "'s Schedule " . $_POST['fyear'] . "-" . $_POST['lyear']);
	$pdf->AddPage();
	$pdf->SetAutoPageBreak(false);
	$pdf->SetMargins(0, 0, 0);
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	$pdf->SetFillColor(255, 105, 0);
	$pdf->Rect(0, 0, 210, 297, 'FD');
	$pdf->SetFillColor(0, 0, 0);
	$pdf->Rect(22, 17.5, 165, 16.98, 'F');
	$pdf->Rect(29, 52.8, 19.75, 27.5, 'F');
	$pdf->Rect(48.75, 80.3, 19.75, 27.5, 'F');
	$pdf->Rect(68.5, 52.8, 19.75, 27.5, 'F');
	$pdf->Rect(88.25, 80.3, 19.75, 27.5, 'F');
	$pdf->Rect(108, 52.8, 19.75, 27.5, 'F');
	$pdf->Rect(127.75, 80.3, 19.75, 27.5, 'F');
	$pdf->Rect(147.5, 52.8, 19.75, 27.5, 'F');
	$pdf->Rect(167.25, 80.3, 19.75, 27.5, 'F');
	$pdf->Rect(29, 105, 19.75, 27.5, 'F');
	$pdf->Rect(48.75, 130.78, 19.75, 27.5, 'F');
	$pdf->Rect(68.5, 105, 19.75, 27.5, 'F');
	$pdf->Rect(88.25, 130.78, 19.75, 27.5, 'F');
	$pdf->Rect(108, 105, 19.75, 27.5, 'F');
	$pdf->Rect(127.75, 130.78, 19.75, 27.5, 'F');
	$pdf->Rect(147.5, 105, 19.75, 27.5, 'F');
	$pdf->Rect(167.25, 130.78, 19.75, 27.5, 'F');
	$pdf->Rect(29, 158.28, 19.75, 27.5, 'F');
	$pdf->Rect(68.5, 158.28, 19.75, 27.5, 'F');
	$pdf->Rect(108, 158.28, 19.75, 27.5, 'F');
	$pdf->Rect(147.5, 158.28, 19.75, 27.5, 'F');
	$pdf->Rect(29, 215, 19.75, 27.5, 'F');
	$pdf->Rect(68.5, 215, 19.75, 27.5, 'F');
	$pdf->Rect(108, 215, 19.75, 27.5, 'F');
	$pdf->Rect(147.5, 215, 19.75, 27.5, 'F');
	$pdf->Rect(48.75, 185, 19.75, 27.5, 'F');
	$pdf->Rect(88.25, 185, 19.75, 27.5, 'F');
	$pdf->Rect(127.75, 185, 19.75, 27.5, 'F');
	$pdf->Rect(167.25, 185, 19.75, 27.5, 'F');
	$pdf->SetFillColor(255, 255, 255);
	$pdf->Rect(29, 240, 158, 27.5, 'F');
	$pdf->SetXY(22, 17.5);
	$pdf->SetMargins(22, 17.5, 23);
	$pdf->SetLineWidth(.1);
	
	//Cats
	$pdf->Image("Cats/PlayfulCat.jpg", 5, 2, 30, 15);
	$pdf->Image("Cats/PlayfulCat2.gif", 40, 2, 30, 15);
	$pdf->Image("Cats/SkinnyCat.jpg", 80, 2, 20, 15);
	$pdf->Image("Cats/BunchesofCats.jpg", 110, 2, 30, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 143, 2, 30, 15);
	$pdf->Image("Cats/TinyCat.jpg", 175, 2, 30, 15);
	$pdf->Image("Cats/TongueCat.jpg", 5, 277.5, 30, 15);
	$pdf->Image("Cats/CreeperCat.jpg", 90,34, 30, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 175, 277.5, 30, 15);
	$pdf->Image("Cats/SkinnyCat.jpg", 40, 277.5, 20, 15);
	$pdf->Image("Cats/PlayfulCat2.gif", 60, 277.5, 30, 15);
	$pdf->Image("Cats/PlayfulCat.jpg", 90, 277.5, 30, 15);
	$pdf->Image("Cats/BunchesofCats.jpg", 120, 277.5, 30, 15);
	$pdf->Image("Cats/TinyCat.jpg", 150, 277.5, 30, 15);
	$pdf->Image("Cats/TongueCat.jpg", 3, 20, 15, 15);
	$pdf->Image("Cats/BoringCat.jpg", 3, 40, 15, 15);
	$pdf->Image("Cats/BunchesofCats2.jpg", 3, 60, 20, 15);
	$pdf->Image("Cats/ConfusedCat.jpg", 3, 80, 15, 15);
	$pdf->Image("Cats/ReachingCat.jpg", 3, 100, 15, 15);
	$pdf->Image("Cats/PoisedCat.jpg", 3, 120, 15, 15);
	$pdf->Image("Cats/NiceCat.jpg", 3, 140, 15, 15);
	$pdf->Image("Cats/PlayfulCat.jpg", 3, 160, 15, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 3, 180, 15, 15);
	$pdf->Image("Cats/TinyCat.jpg", 3, 200, 15, 15);
	$pdf->Image("Cats/TongueCat.jpg", 3, 220, 15, 15);
	$pdf->Image("Cats/CuteCat.jpg", 3, 240, 15, 15);
	$pdf->Image("Cats/StudyingCat.gif", 3, 260, 15, 15);
	$pdf->Image("Cats/FatCat.jpg", 190, 20, 15, 15);
	$pdf->Image("Cats/GrumpyCat.jpg", 190, 40, 15, 15);
	$pdf->Image("Cats/PretentiousCat.jpg", 190, 60, 15, 15);
	$pdf->Image("Cats/SadCats.jpg", 190, 80, 15, 15);
	$pdf->Image("Cats/CuteCat.jpg", 190, 100, 15, 15);
	$pdf->Image("Cats/PoisedCat.jpg", 190, 120, 15, 15);
	$pdf->Image("Cats/SkinnyCat.jpg", 190, 140, 15, 15);
	$pdf->Image("Cats/StudyingCat.gif", 190, 160, 15, 15);
	$pdf->Image("Cats/TinyCat.jpg", 190, 180, 15, 15);
	$pdf->Image("Cats/AmericanCats.jpg", 190, 200, 15, 15);
	$pdf->Image("Cats/StudyingCat.gif", 190, 220, 15, 15);
	$pdf->Image("Cats/PlayfulCat.jpg", 190, 240, 15, 15);
	$pdf->Image("Cats/PretentiousCat.jpg", 190, 260, 15, 15);

	//Header
	$pdf->SetFillColor(0, 0, 0);
	$pdf->Cell(77, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 4, $_POST['fyear'] . "-" . $_POST['lyear'], 'RL', 0, 'C', true);
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(0, 4, "Student Schedule for " . $_POST['lname'] . ", " . $_POST['fname'] . " " . $_POST['minitial'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 5.66, "Ridgefield High School", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	if (strlen($_POST['studentnum']) == 0)
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Student Number: " . $_POST['studentnum'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	$pdf->Ln();
	$pdf->SetFont("Times", '', 10);
	$pdf->Cell(77, 4, "700 N Salem Rd, Ridgefield CT 06877", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	$pdf->Cell(0, 4, "Term Q1 Q2 Q3 Q4   Courses enrolled: " . $_POST['enrolled'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->Cell(77, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Ln(10);

	//First Line
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->SetFont("Times", 'B', 8);
	$pdf->Cell(7, 10, "", 1, 0, 'C', true);
	if ($_POST['semester'] == 1)
	{
		$pdf->Cell(0, 5, "Term Q1 Q2", 1, 2, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5, "Term Q3 Q4", 1, 2, 'C', true);
	}
	$pdf->Cell(19.75, 5, "A", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "B", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "C", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "D", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "E", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "F", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "G", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "H", 1, 0, 'C', true);
	$pdf->Ln();

	//Periods
	$pdf->Cell(7, 27.5, "1st", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "2nd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "3rd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "4th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "5th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "6th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "7th", 1, 2, 'C', true);
	$pdf->Cell(7, 22.5, "X", 1, 2, 'C', true);
	$pdf->SetFont("Times", 'B', 7);
	$pdf->Cell(7, 5, "MISC", 1, 0, 'C', true);
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//A Day
	$pdf->SetXY(29, 52.8);
	$inc = 0;
	for ($a = 0; $a < 7; $a++)
	{
		if ($a % 2 == 0)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$a1 = $pdf->sec(1, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a1 == 1)
				$a--;
			else if ($a1 == 2)
				$a++;
		}
		else if ($inc == 1)
		{
			$a2 = $pdf->sec(2, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a2 == 1)
				$a--;
			else if ($a2 == 2)
				$a++;
		}
		else if ($inc == 2)
		{
			$a3 = $pdf->sec(3, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a3 == 1)
				$a--;
			else if ($a3 == 2)
				$a++;
		}
		else if ($inc == 3)
		{
			$a4 = $pdf->sec(4, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a4 == 1)
				$a--;
			else if ($a4 == 2)
				$a++;
		}
		else if ($inc == 4)
		{
			$a5 = $pdf->sec(5, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a5 == 1)
				$a--;
			else if ($a5 == 2)
				$a++;
		}
		else if ($inc == 5)
		{
			$a6 = $pdf->sec(6, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a6 == 1)
				$a--;
			else if ($a6 == 2)
				$a++;
		}
		else if ($inc == 6)
		{
			$a7 = $pdf->sec(7, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a7 == 1)
				$a--;
			else if ($a7 == 2)
				$a++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//B Day
	$pdf->SetXY(48.75, 52.8);
	$inc = 0;
	for ($b = 0; $b < 7; $b++)
	{
		if ($b % 2 == 1)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$b1 = $pdf->sec(2, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b1 == 1)
				$b--;
			else if ($b1 == 2)
				$b++;
		}
		else if ($inc == 1)
		{
			$b2 = $pdf->sec(3, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b2 == 1)
				$b--;
			else if ($b2 == 2)
				$b++;
		}
		else if ($inc == 2)
		{
			$b3 = $pdf->sec(1, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b3 == 1)
				$b--;
			else if ($b3 == 2)
				$b++;
		}
		else if ($inc == 3)
		{
			$b4 = $pdf->sec(7, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b4 == 1)
				$b--;
			else if ($b4 == 2)
				$b++;
		}
		else if ($inc == 4)
		{
			$b5 = $pdf->sec(8, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b5 == 1)
				$b--;
			else if ($b5 == 2)
				$b++;
		}
		else if ($inc == 5)
		{
			$b6 = $pdf->sec(5, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b6 == 1)
				$b--;
			else if ($b6 == 2)
				$b++;
		}
		else if ($inc == 6)
		{
			$b7 = $pdf->sec(6, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b7 == 1)
				$b--;
			else if ($b7 == 2)
				$b++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//C Day
	$pdf->SetXY(68.5, 52.8);
	$inc = 0;
	for ($c = 0; $c < 7; $c++)
	{
		if ($c % 2 == 0)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$c1 = $pdf->sec(3, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c1 == 1)
				$c--;
			else if ($c1 == 2)
				$c++;
		}
		else if ($inc == 1)
		{
			$c2 = $pdf->sec(1, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c2 == 1)
				$c--;
			else if ($c2 == 2)
				$c++;
		}
		else if ($inc == 2)
		{
			$c3 = $pdf->sec(4, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c3 == 1)
				$c--;
			else if ($c3 == 2)
				$c++;
		}
		else if ($inc == 3)
		{
			$c4 = $pdf->sec(2, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c4 == 1)
				$c--;
			else if ($c4 == 2)
				$c++;
		}
		else if ($inc == 4)
		{
			$c5 = $pdf->sec(6, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c5 == 1)
				$c--;
			else if ($c5 == 2)
				$c++;
		}
		else if ($inc == 5)
		{
			$c6 = $pdf->sec(8, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c6 == 1)
				$c--;
			else if ($c6 == 2)
				$c++;
		}
		else if ($inc == 6)
		{
			$c7 = $pdf->sec(5, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c7 == 1)
				$c--;
			else if ($c7 == 2)
				$c++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//D Day
	$pdf->SetXY(88.25, 52.8);
	$inc = 0;
	for ($d = 0; $d < 7; $d++)
	{
		if ($d % 2 == 1)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$d1 = $pdf->sec(1, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d1 == 1)
				$d--;
			else if ($d1 == 2)
				$d++;
		}
		else if ($inc == 1)
		{
			$d2 = $pdf->sec(4, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d2 == 1)
				$d--;
			else if ($d2 == 2)
				$d++;
		}
		else if ($inc == 2)
		{
			$d3 = $pdf->sec(3, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d3 == 1)
				$d--;
			else if ($d3 == 2)
				$d++;
		}
		else if ($inc == 3)
		{
			$d4 = $pdf->sec(5, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d4 == 1)
				$d--;
			else if ($d4 == 2)
				$d++;
		}
		else if ($inc == 4)
		{
			$d5 = $pdf->sec(7, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d5 == 1)
				$d--;
			else if ($d5 == 2)
				$d++;
		}
		else if ($inc == 5)
		{
			$d6 = $pdf->sec(6, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d6 == 1)
				$d--;
			else if ($d6 == 2)
				$d++;
		}
		else if ($inc == 6)
		{
			$d7 = $pdf->sec(8, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d7 == 1)
				$d--;
			else if ($d7 == 2)
				$d++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//E Day
	$pdf->SetXY(108, 52.8);
	$inc = 0;
	for ($e = 0; $e < 7; $e++)
	{
		if ($e % 2 == 0)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$e1 = $pdf->sec(4, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e1 == 1)
				$e--;
			else if ($e1 == 2)
				$e++;
		}
		else if ($inc == 1)
		{
			$e2 = $pdf->sec(3, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e2 == 1)
				$e--;
			else if ($e2 == 2)
				$e++;
		}
		else if ($inc == 2)
		{
			$e3 = $pdf->sec(2, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e3 == 1)
				$e--;
			else if ($e3 == 2)
				$e++;
		}
		else if ($inc == 3)
		{
			$e4 = $pdf->sec(1, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e4 == 1)
				$e--;
			else if ($e4 == 2)
				$e++;
		}
		else if ($inc == 4)
		{
			$e5 = $pdf->sec(8, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e5 == 1)
				$e--;
			else if ($e5 == 2)
				$e++;
		}
		else if ($inc == 5)
		{
			$e6 = $pdf->sec(7, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e6 == 1)
				$e--;
			else if ($e6 == 2)
				$e++;
		}
		else if ($inc == 6)
		{
			$e7 = $pdf->sec(6, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e7 == 1)
				$e--;
			else if ($e7 == 2)
				$e++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//F Day
	$pdf->SetXY(127.75, 52.8);
	$inc = 0;
	for ($f = 0; $f < 7; $f++)
	{
		if ($f % 2 == 1)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$f1 = $pdf->sec(3, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f1 == 1)
				$f--;
			else if ($f1 == 2)
				$f++;
		}
		else if ($inc == 1)
		{
			$f2 = $pdf->sec(2, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f2 == 1)
				$f--;
			else if ($f2 == 2)
				$f++;
		}
		else if ($inc == 2)
		{
			$f3 = $pdf->sec(4, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f3 == 1)
				$f--;
			else if ($f3 == 2)
				$f++;
		}
		else if ($inc == 3)
		{
			$f4 = $pdf->sec(6, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f4 == 1)
				$f--;
			else if ($f4 == 2)
				$f++;
		}
		else if ($inc == 4)
		{
			$f5 = $pdf->sec(5, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f5 == 1)
				$f--;
			else if ($f5 == 2)
				$f++;
		}
		else if ($inc == 5)
		{
			$f6 = $pdf->sec(8, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f6 == 1)
				$f--;
			else if ($f6 == 2)
				$f++;
		}
		else if ($inc == 6)
		{
			$f7 = $pdf->sec(7, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f7 == 1)
				$f--;
			else if ($f7 == 2)
				$f++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//G Day
	$pdf->SetXY(147.5, 52.8);
	$inc = 0;
	for ($g = 0; $g < 7; $g++)
	{
		if ($g % 2 == 0)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$g1 = $pdf->sec(2, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g1 == 1)
				$g--;
			else if ($g1 == 2)
				$g++;
		}
		else if ($inc == 1)
		{
			$g2 = $pdf->sec(4, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g2 == 1)
				$g--;
			else if ($g2 == 2)
				$g++;
		}
		else if ($inc == 2)
		{
			$g3 = $pdf->sec(1, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g3 == 1)
				$g--;
			else if ($g3 == 2)
				$g++;
		}
		else if ($inc == 3)
		{
			$g4 = $pdf->sec(3,"G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g4 == 1)
				$g--;
			else if ($g4 == 2)
				$g++;
		}
		else if ($inc == 4)
		{
			$g5 = $pdf->sec(7, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g5 == 1)
				$g--;
			else if ($g5 == 2)
				$g++;
		}
		else if ($inc == 5)
		{
			$g6 = $pdf->sec(5, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g6 == 1)
				$g--;
			else if ($g6 == 2)
				$g++;
		}
		else if ($inc == 6)
		{
			$g7 = $pdf->sec(8, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g7 == 1)
				$g--;
			else if ($g7 == 2)
				$g++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
	
	//H Day
	$pdf->SetXY(167.25, 52.8);
	$inc = 0;
	for ($h = 0; $h < 7; $h++)
	{
		if ($h % 2 == 1)
			$pdf->SetFillColor(0, 0, 0);
		else
			$pdf->SetFillColor(255, 105, 0);
		if ($inc == 0)
		{
			$h1 = $pdf->sec(4, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h1 == 1)
				$h--;
			else if ($h1 == 2)
				$h++;
		}
		else if ($inc == 1)
		{
			$h2 = $pdf->sec(1, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h2 == 1)
				$h--;
			else if ($h2 == 2)
				$h++;
		}
		else if ($inc == 2)
		{
			$h3 = $pdf->sec(2, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h3 == 1)
				$h--;
			else if ($h3 == 2)
				$h++;
		}
		else if ($inc == 3)
		{
			$h4 = $pdf->sec(8, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h4 == 1)
				$h--;
			else if ($h4 == 2)
				$h++;
		}
		else if ($inc == 4)
		{
			$h5 = $pdf->sec(6, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h5 == 1)
				$h--;
			else if ($h5 == 2)
				$h++;
		}
		else if ($inc == 5)
		{
			$h6 = $pdf->sec(7, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h6 == 1)
				$h--;
			else if ($h6 == 2)
				$h++;
		}
		else if ($inc == 6)
		{
			$h7 = $pdf->sec(5, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h7 == 1)
				$h--;
			else if ($h7 == 2)
				$h++;
		}
		$inc++;
	}
	$pdf->SetFillColor(255, 255, 255);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetDrawColor(0, 0, 0);
	$pdf->secX();
	$pdf->secMISC();
	$pdf->SetTextColor(255, 255, 255);
	$pdf->SetDrawColor(255, 255, 255);
}
else
{
	//Create Blocks
	class PDF extends FPDF
	{
		function sec($z, $day, $period, $time1, $time2)
		{
			$this->SetFillColor(255, 255, 255);
			if ($_POST['sec' . $z . '-free'] == "true")
			{	
				for ($i = 1; $i <= 8; $i++)
				{
					if (substr($_POST['sec' . $i . '-secnum'], 1, 1) == $z)
					{
						if (isset($_POST['sec' . $i . '-doublelabs']))
						{
							foreach($_POST['sec' . $i . '-doublelabs'] as $j)
							{
								if ($day == $j)
									return 1;
							}
						}
						for ($j = 1; $j <= 8; $j++)
						{
							if ($day == $_POST['sec' . $j . '-switchfourth'] AND $period == 4)
							{
								$this->SetFont("Times", '', 6);
								$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
								$this->SetFont("Times", 'B', 6);
								if (strlen($_POST['sec' . $j . '-name']) < 18)
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								else
								{
									$this->SetFont("Times", 'B', 5);
									$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-name'], 'RL', 2, 'L', true);
								}
								$this->SetFont("Times", '', 6);
								if (strlen($_POST['sec' . $j . '-teacher']) < 20)
								{
								$this->Cell(19.75, 5.5, $_POST['sec' . $j . '-teacher'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
								}
								else
								{
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 0, 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, substr($_POST['sec' . $j . '-teacher'], 20), 'RL', 2, 'L', true);
									$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $j . '-room'], 'RL', 2, 'L', true);
								}	
								return;
							}
						}
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
			}
			else
			{
				if (substr($_POST['sec' . $z . '-secnum'], 0, 1) != substr($_POST['sec' . $z . '-secnum'], 1, 1))
				{
					if (isset($_POST['sec' . $z . '-doublelabs']))
					{
						foreach($_POST['sec' . $z . '-doublelabs'] as $i)
						{
							if ($day == $i)
							{
								$this->doublelab($time1, $time2, $z);
								return 2;
							}
						}
					}
					if ($day == $_POST['sec' . $z . '-switchfourth'])
					{
						$this->SetFont("Times", '', 6);
						$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
						$this->SetFont("Times", 'B', 6);
						$this->Cell(19.75, 5.5, "EMPTY", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RL', 2, 'L', true);
						$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
						return;
					}
				}
				$this->SetFont("Times", '', 6);
				$this->Cell(19.75, 5.5, $time1 . " - " . $time2, 'RTL', 2, 'C', true);
				$this->SetFont("Times", 'B', 6);
				if (strlen($_POST['sec' . $z . '-name']) < 18)
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				else if (strlen($_POST['sec' . $z . '-name']) < 20)
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
				}
				else
				{
					$this->SetFont("Times", 'B', 5);
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'C', true);
				}
				$this->SetFont("Times", '', 6);
				if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
				{
					$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "", 'RBL', 2, 'L', true);
				}
				else
				{
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
					$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				}
			}
		}
		public function secX()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 4.5, "-", 'RTL', 2, 'L', true);
			$this->Cell(19.75, 4.5, substr(2000 + $_POST['fyear'] - $_POST['grade'] - 5, 2, 2) . $_POST['grade'] . "-3", 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Advisory - " . $_POST['grade'], 'RL', 2, 'L', true);
			$this->SetFont("Times", '', 6);
			$this->Cell(19.75, 4.5, $_POST['advisor'] . "/" . $_POST['lcounc'], 'RL', 2, 'L', true);
			$this->Cell(19.75, 4.5, "Room: " . $_POST['adv-rm'], 'RBL', 2, 'L', true);
		}
		public function secMISC()
		{
			$this->SetFont("Times", 'B', 6);
			$this->Cell(19.75, 5, "EMPTY", 1, 2, 'C', true);
		}
		function doublelab($time1, $time2, $z)
		{
			//Times
			$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));
		
			$this->SetFont("Times", '', 6);
			for ($i = 0; $i < 7; $i++)
				if ($times[$i][1] == $time2)
				{
					if ($i == 6)
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i][1], 'RTL', 2, 'C', true);
					else
						$this->Cell(19.75, 5.5, $time1 . " - " . $times[$i + 1][1], 'RTL', 2, 'C', true);
				}	
			$this->SetFont("Times", 'B', 6);
			if (strlen($_POST['sec' . $z . '-name']) < 18)
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			else
			{
				$this->SetFont("Times", 'B', 5);
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-name'], 'RL', 2, 'L', true);
			}
			$this->SetFont("Times", '', 6);
			if (strlen($_POST['sec' . $z . '-teacher']) <= 20)
			{
				$this->Cell(19.75, 5.5, $_POST['sec' . $z . '-teacher'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 33, "", 'RBL', 2, 'L', true);
			}
			else
			{
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 0, 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, substr($_POST['sec' . $z . '-teacher'], 20), 'RL', 2, 'L', true);
				$this->Cell(19.75, 5.5, "Room: " . $_POST['sec' . $z . '-room'], 'RL', 2, 'L', true);
				$this->Cell(19.75, 27.5, "", 'RBL', 2, 'L', true);
			}
		}
	}
	
	//Times
	$times = array(array("7:25 AM", "8:08 AM"), array("8:13 AM", "8:56 AM"), array("9:01 AM", "9:47 AM"), array("9:52 AM", "11:51 AM"), array("11:56 AM", "12:39 PM"), array("12:44 PM", "1:27 PM"), array("1:32 PM", "2:15 PM"));

	//Create PDF
	$pdf = new PDF();

	//Set Page
	$pdf->SetTitle($_POST['fname'] . " " . $_POST['lname'] . "'s Schedule " . $_POST['fyear'] . "-" . $_POST['lyear']);
	$pdf->SetMargins(22, 17.5, 23);
	$pdf->SetLineWidth(.1);
	$pdf->AddPage();

	//Header
	$pdf->SetFillColor(255, 255, 255);
	$pdf->Cell(77, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RTL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 4, $_POST['fyear'] . "-" . $_POST['lyear'], 'RL', 0, 'C', true);
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(0, 4, "Student Schedule for " . $_POST['lname'] . ", " . $_POST['fname'] . " " . $_POST['minitial'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->SetFont("Times", 'B', 10);
	$pdf->Cell(77, 5.66, "Ridgefield High School", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	if (strlen($_POST['studentnum']) == 0)
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5.66, "Grade: " . $_POST['grade'] . "   Student Number: " . $_POST['studentnum'] . "   Counselor: " . $_POST['lcounc'] . ", " . $_POST['fcounc'], 'RL', 0, 'C', true);
	}
	$pdf->Ln();
	$pdf->SetFont("Times", '', 10);
	$pdf->Cell(77, 4, "700 N Salem Rd, Ridgefield CT 06877", 'RL', 0, 'C', true);
	$pdf->SetFont("Times", '', 7);
	$pdf->Cell(0, 4, "Term Q1 Q2 Q3 Q4   Courses enrolled: " . $_POST['enrolled'], 'RL', 0, 'C', true);
	$pdf->Ln();
	$pdf->Cell(77, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Cell(0, 1.66, "", 'RBL', 0, 'C', true);
	$pdf->Ln(10);

	//First Line
	$pdf->SetFillColor(230, 230, 230);
	$pdf->SetFont("Times", 'B', 8);
	$pdf->Cell(7, 10, "", 1, 0, 'C', true);
	if ($_POST['semester'] == 1)
	{
		$pdf->Cell(0, 5, "Term Q1 Q2", 1, 2, 'C', true);
	}
	else
	{
		$pdf->Cell(0, 5, "Term Q3 Q4", 1, 2, 'C', true);
	}
	$pdf->Cell(19.75, 5, "A", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "B", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "C", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "D", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "E", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "F", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "G", 1, 0, 'C', true);
	$pdf->Cell(19.75, 5, "H", 1, 0, 'C', true);
	$pdf->Ln();

	//Periods
	$pdf->Cell(7, 27.5, "1st", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "2nd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "3rd", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "4th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "5th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "6th", 1, 2, 'C', true);
	$pdf->Cell(7, 27.5, "7th", 1, 2, 'C', true);
	$pdf->Cell(7, 22.5, "X", 1, 2, 'C', true);
	$pdf->SetFont("Times", 'B', 7);
	$pdf->Cell(7, 5, "MISC", 1, 0, 'C', true);
	
	//A Day
	$pdf->SetXY(29, 52.8);
	$inc = 0;
	for ($a = 0; $a < 7; $a++)
	{
		if ($inc == 0)
		{
			$a1 = $pdf->sec(1, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a1 == 1)
				$a--;
			else if ($a1 == 2)
				$a++;
		}
		else if ($inc == 1)
		{
			$a2 = $pdf->sec(2, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a2 == 1)
				$a--;
			else if ($a2 == 2)
				$a++;
		}
		else if ($inc == 2)
		{
			$a3 = $pdf->sec(3, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a3 == 1)
				$a--;
			else if ($a3 == 2)
				$a++;
		}
		else if ($inc == 3)
		{
			$a4 = $pdf->sec(4, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a4 == 1)
				$a--;
			else if ($a4 == 2)
				$a++;
		}
		else if ($inc == 4)
		{
			$a5 = $pdf->sec(5, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a5 == 1)
				$a--;
			else if ($a5 == 2)
				$a++;
		}
		else if ($inc == 5)
		{
			$a6 = $pdf->sec(6, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a6 == 1)
				$a--;
			else if ($a6 == 2)
				$a++;
		}
		else if ($inc == 6)
		{
			$a7 = $pdf->sec(7, "A", $a + 1, $times[$a][0], $times[$a][1]);
			if ($a7 == 1)
				$a--;
			else if ($a7 == 2)
				$a++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//B Day
	$pdf->SetXY(48.75, 52.8);
	$inc = 0;
	for ($b = 0; $b < 7; $b++)
	{
		if ($inc == 0)
		{
			$b1 = $pdf->sec(2, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b1 == 1)
				$b--;
			else if ($b1 == 2)
				$b++;
		}
		else if ($inc == 1)
		{
			$b2 = $pdf->sec(3, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b2 == 1)
				$b--;
			else if ($b2 == 2)
				$b++;
		}
		else if ($inc == 2)
		{
			$b3 = $pdf->sec(1, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b3 == 1)
				$b--;
			else if ($b3 == 2)
				$b++;
		}
		else if ($inc == 3)
		{
			$b4 = $pdf->sec(7, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b4 == 1)
				$b--;
			else if ($b4 == 2)
				$b++;
		}
		else if ($inc == 4)
		{
			$b5 = $pdf->sec(8, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b5 == 1)
				$b--;
			else if ($b5 == 2)
				$b++;
		}
		else if ($inc == 5)
		{
			$b6 = $pdf->sec(5, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b6 == 1)
				$b--;
			else if ($b6 == 2)
				$b++;
		}
		else if ($inc == 6)
		{
			$b7 = $pdf->sec(6, "B", $b + 1, $times[$b][0], $times[$b][1]);
			if ($b7 == 1)
				$b--;
			else if ($b7 == 2)
				$b++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//C Day
	$pdf->SetXY(68.5, 52.8);
	$inc = 0;
	for ($c = 0; $c < 7; $c++)
	{
		if ($inc == 0)
		{
			$c1 = $pdf->sec(3, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c1 == 1)
				$c--;
			else if ($c1 == 2)
				$c++;
		}
		else if ($inc == 1)
		{
			$c2 = $pdf->sec(1, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c2 == 1)
				$c--;
			else if ($c2 == 2)
				$c++;
		}
		else if ($inc == 2)
		{
			$c3 = $pdf->sec(4, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c3 == 1)
				$c--;
			else if ($c3 == 2)
				$c++;
		}
		else if ($inc == 3)
		{
			$c4 = $pdf->sec(2, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c4 == 1)
				$c--;
			else if ($c4 == 2)
				$c++;
		}
		else if ($inc == 4)
		{
			$c5 = $pdf->sec(6, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c5 == 1)
				$c--;
			else if ($c5 == 2)
				$c++;
		}
		else if ($inc == 5)
		{
			$c6 = $pdf->sec(8, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c6 == 1)
				$c--;
			else if ($c6 == 2)
				$c++;
		}
		else if ($inc == 6)
		{
			$c7 = $pdf->sec(5, "C", $c + 1, $times[$c][0], $times[$c][1]);
			if ($c7 == 1)
				$c--;
			else if ($c7 == 2)
				$c++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//D Day
	$pdf->SetXY(88.25, 52.8);
	$inc = 0;
	for ($d = 0; $d < 7; $d++)
	{
		if ($inc == 0)
		{
			$d1 = $pdf->sec(1, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d1 == 1)
				$d--;
			else if ($d1 == 2)
				$d++;
		}
		else if ($inc == 1)
		{
			$d2 = $pdf->sec(4, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d2 == 1)
				$d--;
			else if ($d2 == 2)
				$d++;
		}
		else if ($inc == 2)
		{
			$d3 = $pdf->sec(3, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d3 == 1)
				$d--;
			else if ($d3 == 2)
				$d++;
		}
		else if ($inc == 3)
		{
			$d4 = $pdf->sec(5, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d4 == 1)
				$d--;
			else if ($d4 == 2)
				$d++;
		}
		else if ($inc == 4)
		{
			$d5 = $pdf->sec(7, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d5 == 1)
				$d--;
			else if ($d5 == 2)
				$d++;
		}
		else if ($inc == 5)
		{
			$d6 = $pdf->sec(6, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d6 == 1)
				$d--;
			else if ($d6 == 2)
				$d++;
		}
		else if ($inc == 6)
		{
			$d7 = $pdf->sec(8, "D", $d + 1, $times[$d][0], $times[$d][1]);
			if ($d7 == 1)
				$d--;
			else if ($d7 == 2)
				$d++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//E Day
	$pdf->SetXY(108, 52.8);
	$inc = 0;
	for ($e = 0; $e < 7; $e++)
	{
		if ($inc == 0)
		{
			$e1 = $pdf->sec(4, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e1 == 1)
				$e--;
			else if ($e1 == 2)
				$e++;
		}
		else if ($inc == 1)
		{
			$e2 = $pdf->sec(3, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e2 == 1)
				$e--;
			else if ($e2 == 2)
				$e++;
		}
		else if ($inc == 2)
		{
			$e3 = $pdf->sec(2, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e3 == 1)
				$e--;
			else if ($e3 == 2)
				$e++;
		}
		else if ($inc == 3)
		{
			$e4 = $pdf->sec(1, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e4 == 1)
				$e--;
			else if ($e4 == 2)
				$e++;
		}
		else if ($inc == 4)
		{
			$e5 = $pdf->sec(8, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e5 == 1)
				$e--;
			else if ($e5 == 2)
				$e++;
		}
		else if ($inc == 5)
		{
			$e6 = $pdf->sec(7, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e6 == 1)
				$e--;
			else if ($e6 == 2)
				$e++;
		}
		else if ($inc == 6)
		{
			$e7 = $pdf->sec(6, "E", $e + 1, $times[$e][0], $times[$e][1]);
			if ($e7 == 1)
				$e--;
			else if ($e7 == 2)
				$e++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//F Day
	$pdf->SetXY(127.75, 52.8);
	$inc = 0;
	for ($f = 0; $f < 7; $f++)
	{
		if ($inc == 0)
		{
			$f1 = $pdf->sec(3, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f1 == 1)
				$f--;
			else if ($f1 == 2)
				$f++;
		}
		else if ($inc == 1)
		{
			$f2 = $pdf->sec(2, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f2 == 1)
				$f--;
			else if ($f2 == 2)
				$f++;
		}
		else if ($inc == 2)
		{
			$f3 = $pdf->sec(4, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f3 == 1)
				$f--;
			else if ($f3 == 2)
				$f++;
		}
		else if ($inc == 3)
		{
			$f4 = $pdf->sec(6, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f4 == 1)
				$f--;
			else if ($f4 == 2)
				$f++;
		}
		else if ($inc == 4)
		{
			$f5 = $pdf->sec(5, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f5 == 1)
				$f--;
			else if ($f5 == 2)
				$f++;
		}
		else if ($inc == 5)
		{
			$f6 = $pdf->sec(8, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f6 == 1)
				$f--;
			else if ($f6 == 2)
				$f++;
		}
		else if ($inc == 6)
		{
			$f7 = $pdf->sec(7, "F", $f + 1, $times[$f][0], $times[$f][1]);
			if ($f7 == 1)
				$f--;
			else if ($f7 == 2)
				$f++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//G Day
	$pdf->SetXY(147.5, 52.8);
	$inc = 0;
	for ($g = 0; $g < 7; $g++)
	{
		if ($inc == 0)
		{
			$g1 = $pdf->sec(2, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g1 == 1)
				$g--;
			else if ($g1 == 2)
				$g++;
		}
		else if ($inc == 1)
		{
			$g2 = $pdf->sec(4, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g2 == 1)
				$g--;
			else if ($g2 == 2)
				$g++;
		}
		else if ($inc == 2)
		{
			$g3 = $pdf->sec(1, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g3 == 1)
				$g--;
			else if ($g3 == 2)
				$g++;
		}
		else if ($inc == 3)
		{
			$g4 = $pdf->sec(3,"G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g4 == 1)
				$g--;
			else if ($g4 == 2)
				$g++;
		}
		else if ($inc == 4)
		{
			$g5 = $pdf->sec(7, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g5 == 1)
				$g--;
			else if ($g5 == 2)
				$g++;
		}
		else if ($inc == 5)
		{
			$g6 = $pdf->sec(5, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g6 == 1)
				$g--;
			else if ($g6 == 2)
				$g++;
		}
		else if ($inc == 6)
		{
			$g7 = $pdf->sec(8, "G", $g + 1, $times[$g][0], $times[$g][1]);
			if ($g7 == 1)
				$g--;
			else if ($g7 == 2)
				$g++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
	
	//H Day
	$pdf->SetXY(167.25, 52.8);
	$inc = 0;
	for ($h = 0; $h < 7; $h++)
	{
		if ($inc == 0)
		{
			$h1 = $pdf->sec(4, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h1 == 1)
				$h--;
			else if ($h1 == 2)
				$h++;
		}
		else if ($inc == 1)
		{
			$h2 = $pdf->sec(1, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h2 == 1)
				$h--;
			else if ($h2 == 2)
				$h++;
		}
		else if ($inc == 2)
		{
			$h3 = $pdf->sec(2, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h3 == 1)
				$h--;
			else if ($h3 == 2)
				$h++;
		}
		else if ($inc == 3)
		{
			$h4 = $pdf->sec(8, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h4 == 1)
				$h--;
			else if ($h4 == 2)
				$h++;
		}
		else if ($inc == 4)
		{
			$h5 = $pdf->sec(6, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h5 == 1)
				$h--;
			else if ($h5 == 2)
				$h++;
		}
		else if ($inc == 5)
		{
			$h6 = $pdf->sec(7, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h6 == 1)
				$h--;
			else if ($h6 == 2)
				$h++;
		}
		else if ($inc == 6)
		{
			$h7 = $pdf->sec(5, "H", $h + 1, $times[$h][0], $times[$h][1]);
			if ($h7 == 1)
				$h--;
			else if ($h7 == 2)
				$h++;
		}
		$inc++;
	}
	$pdf->secX();
	$pdf->secMISC();
}

//Output
$pdf->Output();
?>