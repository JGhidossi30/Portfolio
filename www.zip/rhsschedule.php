<html dir="ltr" lang="en"><head><title>RHS Schedule Generator</title><meta http-equiv="content-type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><meta http-equiv="Content-Location" content="rhs-schedule-generator.html"><meta name="generator" content="Starfield Technologies; Go Daddy Website Builder v7.0.100"><link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Fredericka+the+Great|Allura|Amatic+SC|Arizonia|Averia+Sans+Libre|Cabin+Sketch|Francois+One|Jacques+Francois+Shadow|Josefin+Slab|Kaushan+Script|Love+Ya+Like+A+Sister|Merriweather|Offside|Open+Sans|Open+Sans+Condensed|Oswald|Over+the+Rainbow|Pacifico|Romanesco|Sacramento|Seaweed+Script|Special+Elite"><link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans"><link rel="stylesheet" type="text/css" href="site.css?v=346460812"><script> if (typeof ($sf) === "undefined") { $sf = { baseUrl: "//img4.wsimg.com/wst/v7/WSB7_J_20140718_1431_nd2_1452/v1", skin: "app", "preload": 0, require: { jquery: "//img4.wsimg.com/wst/v7/WSB7_J_20140718_1431_nd2_1452/v1/libs/jquery/jq.js" } }; } </script><script id="duel" src="//img4.wsimg.com/starfield/duel/v2.5.7/duel.js?appid=O3BkA5J1#TzNCa0E1SjF2Mi41Ljdwcm9k"></script><script src="//img4.wsimg.com/wst/v7/WSB7_J_20140718_1431_nd2_1452/v1/libs/jquery/jq.js" async="" charset="utf-8"></script><script src="//img4.wsimg.com/wst/v7/WSB7_J_20140718_1431_nd2_1452/v1/libs/jquery/jq.js" async="" charset="utf-8"></script><script charset="utf-8" async="" src="//img4.wsimg.com/wst/v7/WSB7_J_20140718_1431_nd2_1452/v1/libs/jquery/jq.js"></script><script charset="utf-8" async="" src="//img4.wsimg.com/wst/v7/WSB7_J_20140718_1431_nd2_1452/v1/modules/cookiemanager/cookiemanager.js"></script><script charset="utf-8" async="" src="//img4.wsimg.com/wst/v7/WSB7_J_20140718_1431_nd2_1452/v1/modules/iebackground/iebackground.js"></script><script src="//img4.wsimg.com/wst/v7/WSB7_J_20140718_1431_nd2_1452/v1/modules/cookiemanager/cookiemanager.js" async="" charset="utf-8"></script><script src="//img4.wsimg.com/wst/v7/WSB7_J_20140718_1431_nd2_1452/v1/modules/iebackground/iebackground.js" async="" charset="utf-8"></script><script src="//img4.wsimg.com/wst/v7/WSB7_J_20140718_1431_nd2_1452/v1/modules/cookiemanager/cookiemanager.js" async="" charset="utf-8"></script><script src="//img4.wsimg.com/wst/v7/WSB7_J_20140718_1431_nd2_1452/v1/modules/iebackground/iebackground.js" async="" charset="utf-8"></script></head><body><style type="text/css"> #wsb-element-346342393{top:120px;left:70px;position:absolute;z-index:12}#wsb-element-346342393 .wsb-htmlsnippet-element{width:822px;height:1500px;overflow:hidden;margin:auto}#wsb-element-346378107{top:10px;left:70px;position:absolute;z-index:14}#wsb-element-346378107 .wsb-image-inner{}#wsb-element-346378107 .wsb-image-inner div{width:423px;height:106px;position:relative;overflow:hidden}#wsb-element-346378107 img{position:absolute} </style><div class="wsb-canvas body" style="background-color: #191919; background-position-x: center; background-position-y: top; background-position: center top; background-repeat: no-repeat; position: fixed; top: 0; bottom: 0; left: 0; right: 0; width: 100%; height: 100%; overflow: hidden;"><div class="wsb-canvas-page-container" style="position: absolute; top: 0; bottom: 0; left: 0; right: 0; width: 100%; height: 100%; overflow: auto;"><div id="wsb-canvas-template-page" class="wsb-canvas-page page" style="height: 1150px; margin: auto; width: 925px; background-color: #ff6900; position: relative; margin-top: 50px"><div id="wsb-canvas-template-container" style="position: absolute;"> <div id="wsb-element-346342393" class="wsb-element-htmlsnippet" data-type="element">
	<style>
body
{
	font-family: "Times New Roman", Times, serif;
	font-size: 10px;	
}
input
{
	font-family: "Times New Roman", Times, serif;
	font-size: 11px;
	border: 1px solid #000000;
	background-color: #ffffff;
}
	</style>
	<div class="wsb-htmlsnippet-element">
		<font color="#000000" face="times new roman">
            <form action="http://www.JGhidossi.com/schedule.php" method="POST">
                <table style="width:96%;text-align:center;border-collapse:collapse;border:1px solid #000000" cellpadding="5" border="1">
                    <tbody>
                        <tr>
                            <td>
                            </td>
                            <td>

                              <b>Class</b>

                            </td>
                            <td>

                              <b>Room</b>

                            </td>
                            <td>

                              <b>Teacher</b>

                            </td>
                            <td>

                              <b>Free?</b>

                            </td>
                            <td>

                              <b>Switches to 4th</b>

                            </td>
                            <td>

                              <b>Double Labs</b>

                            </td>
                            <td>

                              <b>Section #</b>

                            </td>
                        </tr>
                        <tr>
                            <td>

                              <b>1st</b>

                            </td>
                            <td>
                                <input name="sec1-name" type="text">
                            </td>
                            <td>
                                <input maxlength="4" name="sec1-room" size="4" type="text">
                            </td>
                            <td>
                                <input name="sec1-teacher" type="text">
                            </td>
                            <td>
                                <select name="sec1-free">
                                    <option selected="" value="false">

                                        No

                                    
                                    </option><option value="true">

                                        Yes

                                    
                                </option></select>
                            </td>
                            <td>
                                <select name="sec1-switchfourth">
                                    <option selected="" value="none">

                                        --

                                    
                                    </option><option value="A">

                                        A

                                    
                                    </option><option value="B">

                                        B

                                    
                                    </option><option value="C">

                                        C

                                    
                                    </option><option value="D">

                                        D

                                    
                                    </option><option value="E">

                                        E

                                    
                                    </option><option value="F">

                                        F

                                    
                                    </option><option value="G">

                                        G

                                    
                                    </option><option value="H">

                                        H

                                    
                                </option></select>
                            </td>
                            <td>
                                <input name="sec1-doublelabs[]" value="A" type="checkbox">

                                A

                                <input name="sec1-doublelabs[]" value="B" type="checkbox">

                                B

                                <input name="sec1-doublelabs[]" value="C" type="checkbox">

                                C

                                <input name="sec1-doublelabs[]" value="D" type="checkbox">

                                D

                                <input name="sec1-doublelabs[]" value="E" type="checkbox">

                                E

                                <input name="sec1-doublelabs[]" value="F" type="checkbox">

                                F

                                <input name="sec1-doublelabs[]" value="G" type="checkbox">

                                G

                                <input name="sec1-doublelabs[]" value="H" type="checkbox">

                                H 

                            </td>
                            <td>
                                <input maxlength="3" name="sec1-secnum" size="3" type="text">
                            </td>
                        </tr>
                        <tr>
                            <td>

                              <b>2nd</b>

                            </td>
                            <td>
                                <input name="sec2-name" type="text">
                            </td>
                            <td>
                                <input maxlength="4" name="sec2-room" size="4" type="text">
                            </td>
                            <td>
                                <input name="sec2-teacher" type="text">
                            </td>
                            <td>
                                <select name="sec2-free">
                                    <option selected="" value="false">

                                        No

                                    
                                    </option><option value="true">

                                        Yes

                                    
                                </option></select>
                            </td>
                            <td>
                                <select name="sec2-switchfourth">
                                    <option selected="" value="none">

                                        --

                                    
                                    </option><option value="A">

                                        A

                                    
                                    </option><option value="B">

                                        B

                                    
                                    </option><option value="C">

                                        C

                                    
                                    </option><option value="D">

                                        D

                                    
                                    </option><option value="E">

                                        E

                                    
                                    </option><option value="F">

                                        F

                                    
                                    </option><option value="G">

                                        G

                                    
                                    </option><option value="H">

                                        H

                                    
                                </option></select>
                            </td>
                            <td>
                                <input name="sec2-doublelabs[]" value="A" type="checkbox">

                                A

                                <input name="sec2-doublelabs[]" value="B" type="checkbox">

                                B

                                <input name="sec2-doublelabs[]" value="C" type="checkbox">

                                C

                                <input name="sec2-doublelabs[]" value="D" type="checkbox">

                                D

                                <input name="sec2-doublelabs[]" value="E" type="checkbox">

                                E

                                <input name="sec2-doublelabs[]" value="F" type="checkbox">

                                F

                                <input name="sec2-doublelabs[]" value="G" type="checkbox">

                                G

                                <input name="sec2-doublelabs[]" value="H" type="checkbox">

                                H 

                            </td>
                            <td>
                                <input maxlength="3" name="sec2-secnum" size="3" type="text">
                            </td>
                        </tr>
                        <tr>
                            <td>

                              <b>3rd</b>

                            </td>
                            <td>
                                <input name="sec3-name" type="text">
                            </td>
                            <td>
                                <input maxlength="4" name="sec3-room" size="4" type="text">
                            </td>
                            <td>
                                <input name="sec3-teacher" type="text">
                            </td>
                            <td>
                                <select name="sec3-free">
                                    <option selected="" value="false">

                                        No

                                    
                                    </option><option value="true">

                                        Yes

                                    
                                </option></select>
                            </td>
                            <td>
                                <select name="sec3-switchfourth">
                                    <option selected="" value="none">

                                        --

                                    
                                    </option><option value="A">

                                        A

                                    
                                    </option><option value="B">

                                        B

                                    
                                    </option><option value="C">

                                        C

                                    
                                    </option><option value="D">

                                        D

                                    
                                    </option><option value="E">

                                        E

                                    
                                    </option><option value="F">

                                        F

                                    
                                    </option><option value="G">

                                        G

                                    
                                    </option><option value="H">

                                        H

                                    
                                </option></select>
                            </td>
                            <td>
                                <input name="sec3-doublelabs[]" value="A" type="checkbox">

                                A

                                <input name="sec3-doublelabs[]" value="B" type="checkbox">

                                B

                                <input name="sec3-doublelabs[]" value="C" type="checkbox">

                                C

                                <input name="sec3-doublelabs[]" value="D" type="checkbox">

                                D

                                <input name="sec3-doublelabs[]" value="E" type="checkbox">

                                E

                                <input name="sec3-doublelabs[]" value="F" type="checkbox">

                                F

                                <input name="sec3-doublelabs[]" value="G" type="checkbox">

                                G

                                <input name="sec3-doublelabs[]" value="H" type="checkbox">

                                H 

                            </td>
                            <td>
                                <input maxlength="3" name="sec3-secnum" size="3" type="text">
                            </td>
                        </tr>
                        <tr>
                            <td>

                              <b>4th</b>

                            </td>
                            <td>
                                <input name="sec4-name" type="text">
                            </td>
                            <td>
                                <input maxlength="4" name="sec4-room" size="4" type="text">
                            </td>
                            <td>
                                <input name="sec4-teacher" type="text">
                            </td>
                            <td>
                                <select name="sec4-free">
                                    <option selected="" value="false">

                                        No

                                    
                                    </option><option value="true">

                                        Yes

                                    
                                </option></select>
                            </td>
                            <td>
                                <select name="sec4-switchfourth">
                                    <option selected="" value="none">

                                        --

                                    
                                    </option><option value="A">

                                        A

                                    
                                    </option><option value="B">

                                        B

                                    
                                    </option><option value="C">

                                        C

                                    
                                    </option><option value="D">

                                        D

                                    
                                    </option><option value="E">

                                        E

                                    
                                    </option><option value="F">

                                        F

                                    
                                    </option><option value="G">

                                        G

                                    
                                    </option><option value="H">

                                        H

                                    
                                </option></select>
                            </td>
                            <td>
                                <input name="sec4-doublelabs[]" value="A" type="checkbox">

                                A

                                <input name="sec4-doublelabs[]" value="B" type="checkbox">

                                B

                                <input name="sec4-doublelabs[]" value="C" type="checkbox">

                                C

                                <input name="sec4-doublelabs[]" value="D" type="checkbox">

                                D

                                <input name="sec4-doublelabs[]" value="E" type="checkbox">

                                E

                                <input name="sec4-doublelabs[]" value="F" type="checkbox">

                                F

                                <input name="sec4-doublelabs[]" value="G" type="checkbox">

                                G

                                <input name="sec4-doublelabs[]" value="H" type="checkbox">

                                H 

                            </td>
                            <td>
                                <input maxlength="3" name="sec4-secnum" size="3" type="text">
                            </td>
                        </tr>
                        <tr>
                            <td>

                              <b>5th</b>

                            </td>
                            <td>
                                <input name="sec5-name" type="text">
                            </td>
                            <td>
                                <input maxlength="4" name="sec5-room" size="4" type="text">
                            </td>
                            <td>
                                <input name="sec5-teacher" type="text">
                            </td>
                            <td>
                                <select name="sec5-free">
                                    <option selected="" value="false">

                                        No

                                    
                                    </option><option value="true">

                                        Yes

                                    
                                </option></select>
                            </td>
                            <td>
                                <select name="sec5-switchfourth">
                                    <option selected="" value="none">

                                        --

                                    
                                    </option><option value="A">

                                        A

                                    
                                    </option><option value="B">

                                        B

                                    
                                    </option><option value="C">

                                        C

                                    
                                    </option><option value="D">

                                        D

                                    
                                    </option><option value="E">

                                        E

                                    
                                    </option><option value="F">

                                        F

                                    
                                    </option><option value="G">

                                        G

                                    
                                    </option><option value="H">

                                        H

                                    
                                </option></select>
                            </td>
                            <td>
                                <input name="sec5-doublelabs[]" value="A" type="checkbox">

                                A

                                <input name="sec5-doublelabs[]" value="B" type="checkbox">

                                B

                                <input name="sec5-doublelabs[]" value="C" type="checkbox">

                                C

                                <input name="sec5-doublelabs[]" value="D" type="checkbox">

                                D

                                <input name="sec5-doublelabs[]" value="E" type="checkbox">

                                E

                                <input name="sec5-doublelabs[]" value="F" type="checkbox">

                                F

                                <input name="sec5-doublelabs[]" value="G" type="checkbox">

                                G

                                <input name="sec5-doublelabs[]" value="H" type="checkbox">

                                H 

                            </td>
                            <td>
                                <input maxlength="3" name="sec5-secnum" size="3" type="text">
                            </td>
                        </tr>
                        <tr>
                            <td>

                              <b>6th</b>

                            </td>
                            <td>
                                <input name="sec6-name" type="text">
                            </td>
                            <td>
                                <input maxlength="4" name="sec6-room" size="4" type="text">
                            </td>
                            <td>
                                <input name="sec6-teacher" type="text">
                            </td>
                            <td>
                                <select name="sec6-free">
                                    <option selected="" value="false">

                                        No

                                    
                                    </option><option value="true">

                                        Yes

                                    
                                </option></select>
                            </td>
                            <td>
                                <select name="sec6-switchfourth">
                                    <option selected="" value="none">

                                        --

                                    
                                    </option><option value="A">

                                        A

                                    
                                    </option><option value="B">

                                        B

                                    
                                    </option><option value="C">

                                        C

                                    
                                    </option><option value="D">

                                        D

                                    
                                    </option><option value="E">

                                        E

                                    
                                    </option><option value="F">

                                        F

                                    
                                    </option><option value="G">

                                        G

                                    
                                    </option><option value="H">

                                        H

                                    
                                </option></select>
                            </td>
                            <td>
                                <input name="sec6-doublelabs[]" value="A" type="checkbox">

                                A

                                <input name="sec6-doublelabs[]" value="B" type="checkbox">

                                B

                                <input name="sec6-doublelabs[]" value="C" type="checkbox">

                                C

                                <input name="sec6-doublelabs[]" value="D" type="checkbox">

                                D

                                <input name="sec6-doublelabs[]" value="E" type="checkbox">

                                E

                                <input name="sec6-doublelabs[]" value="F" type="checkbox">

                                F

                                <input name="sec6-doublelabs[]" value="G" type="checkbox">

                                G

                                <input name="sec6-doublelabs[]" value="H" type="checkbox">

                                H 

                            </td>
                            <td>
                                <input maxlength="3" name="sec6-secnum" size="3" type="text">
                            </td>
                        </tr>
                        <tr>
                            <td>

                              <b>7th</b>

                            </td>
                            <td>
                                <input name="sec7-name" type="text">
                            </td>
                            <td>
                                <input maxlength="4" name="sec7-room" size="4" type="text">
                            </td>
                            <td>
                                <input name="sec7-teacher" type="text">
                            </td>
                            <td>
                                <select name="sec7-free">
                                    <option selected="" value="false">

                                        No

                                    
                                    </option><option value="true">

                                        Yes

                                    
                                </option></select>
                            </td>
                            <td>
                                <select name="sec7-switchfourth">
                                    <option selected="" value="none">

                                        --

                                    
                                    </option><option value="A">

                                        A

                                    
                                    </option><option value="B">

                                        B

                                    
                                    </option><option value="C">

                                        C

                                    
                                    </option><option value="D">

                                        D

                                    
                                    </option><option value="E">

                                        E

                                    
                                    </option><option value="F">

                                        F

                                    
                                    </option><option value="G">

                                        G

                                    
                                    </option><option value="H">

                                        H

                                    
                                </option></select>
                            </td>
                            <td>
                                <input name="sec7-doublelabs[]" value="A" type="checkbox">

                                A

                                <input name="sec7-doublelabs[]" value="B" type="checkbox">

                                B

                                <input name="sec7-doublelabs[]" value="C" type="checkbox">

                                C

                                <input name="sec7-doublelabs[]" value="D" type="checkbox">

                                D

                                <input name="sec7-doublelabs[]" value="E" type="checkbox">

                                E

                                <input name="sec7-doublelabs[]" value="F" type="checkbox">

                                F

                                <input name="sec7-doublelabs[]" value="G" type="checkbox">

                                G

                                <input name="sec7-doublelabs[]" value="H" type="checkbox">

                                H 

                            </td>
                            <td>
                                <input maxlength="3" name="sec7-secnum" size="3" type="text">
                            </td>
                        </tr>
                        <tr>
                            <td>

                              <b>8th</b>

                            </td>
                            <td>
                                <input name="sec8-name" type="text">
                            </td>
                            <td>
                                <input maxlength="4" name="sec8-room" size="4" type="text">
                            </td>
                            <td>
                                <input name="sec8-teacher" type="text">
                            </td>
                            <td>
                                <select name="sec8-free">
                                    <option selected="" value="false">

                                        No

                                    
                                    </option><option value="true">

                                        Yes

                                    
                                </option></select>
                            </td>
                            <td>
                                <select name="sec8-switchfourth">
                                    <option selected="" value="none">

                                        --

                                    
                                    </option><option value="A">

                                        A

                                    
                                    </option><option value="B">

                                        B

                                    
                                    </option><option value="C">

                                        C

                                    
                                    </option><option value="D">

                                        D

                                    
                                    </option><option value="E">

                                        E

                                    
                                    </option><option value="F">

                                        F

                                    
                                    </option><option value="G">

                                        G

                                    
                                    </option><option value="H">

                                        H

                                    
                                </option></select>
                            </td>
                            <td>
                                <input name="sec8-doublelabs[]" value="A" type="checkbox">

                                A

                                <input name="sec8-doublelabs[]" value="B" type="checkbox">

                                B

                                <input name="sec8-doublelabs[]" value="C" type="checkbox">

                                C

                                <input name="sec8-doublelabs[]" value="D" type="checkbox">

                                D

                                <input name="sec8-doublelabs[]" value="E" type="checkbox">

                                E

                                <input name="sec8-doublelabs[]" value="F" type="checkbox">

                                F

                                <input name="sec8-doublelabs[]" value="G" type="checkbox">

                                G

                                <input name="sec8-doublelabs[]" value="H" type="checkbox">

                                H 

                            </td>
                            <td>
                                <input maxlength="3" name="sec8-secnum" size="3" type="text">
                            </td>
                        </tr>
                        <tr>
                        <td colspan="8">
                            <label for="fyear">

                                    Year '

                            </label>
                          <input maxlength="2" name="fyear" size="2" required="" type="text">
                            <label for="lyear">

                                     - '

                            </label>
                          <input maxlength="2" name="lyear" size="2" required="" type="text">
                           <label for="grade">

                                    Grade

                            </label>
                          <select name="grade">
                                    <option value="9">

                                        9
                                    
                                    </option><option value="10">

                                        10
                                    
									</option><option value="11">
									
										11
										
									</option><option value="12">

										12
										
                          </option></select>
                            <label for="semester">
 
                                    Semester

                            </label>
                            <select name="semester">
                                    <option value="1">

                                        1

                                    
                                    </option><option value="2">

                                        2
                                    
                          </option></select>
                           <label for="studentnum">

                                    Student # 

                            </label>
                            <input maxlength="6" name="studentnum" size="6" type="text">
							<label for="enrolled">
							
									Courses enrolled
									
							</label>
							<select name="enrolled">
                                    <option value="1">

                                        1

                                    </option><option value="2">

                                        2

                                    </option><option value="3">

                                        3

                                    </option><option value="4">

                                        4
										
									</option><option value="5">

                                        5
 
                                    </option><option value="6">

                                        6

                                    </option><option value="7">

                                        7

                                    
                                    </option><option value="8">

                                        8

                                    </option><option value="9">

                                        9

                                    
                                    </option><option value="10">

                                        10
                                    												
                          </option></select>
                          </td>
                      </tr>
                      <tr>
                         <td colspan="8">
                           <label for="fcounc">

                                    Counselor: First Name 

                            </label>
                          <input name="fcounc" required="" type="text">
                           <label for="lcounc">

                                    Last Name 

                            </label>
							<input name="lcounc" required="" type="text">
						</td>
						</tr>
						<tr>
						 <td colspan="8".
                            <label for="advisor">

                                    Advisor: Last Name

                           </label>
                          <input name="advisor" required="" type="text">
                           <label for="adv-rm">
                         
                                    Room

                           </label>
                           <input maxlength="4" name="adv-rm" size="4" required="" type="text">
                         </td>
                        </tr>
                        <tr>
                            <td colspan="8">
                                <label for="fname">

                                    Student: First Name

                                </label>
                                <input name="fname" required="" type="text">
                                <label for="minital">

                                    Middle Intial

                                </label>
                                <input maxlength="1" name="minitial" size="1" required="" type="text">
                                <label for="lname">

                                    Last Name

                                </label>
                                <input name="lname" required="" type="text">
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4">
                              <label for="theme">

                                        Theme

                              </label>
                                <select name="theme">
                                    <option value="Plain">

                                        Plain

                                    
                                    </option><option value="Colored">

                                        Colored

                                    
                                    </option><option value="Tigers">

                                        Tigers

                                    
                                    </option><option value="America">

                                        America
										
									</option><option value="none">
						
										--

									</option><option value="Cats">

                                        Plain Cats
										
									</option><option value="ColoredCats">

                                        Colored Cats
										
									</option><option value="RHSCats">

										RHS Cats
                                    
                              </option></select>
                           </td>
                            <td colspan="4">
                                <input value="Submit" type="submit">
                          </td>
                        </tr>
                    </tbody>
                </table>
          </form>
          </font>
          <font color="#ffffff" face="times new roman" size="2">
		  Create an RHS Block Schedule by inputting your schedule by section number. For an accurate schedule, input the 3 digit section number 
		  for any lab science class. If a lab science has two different sections on the same day, mark that day as "Double Lab." If a lab science 
		  has a different section number on a single day, mark that day as "Switches to 4th." (e.g. 3(B-H) 4(A, E) → Switches to 4th[A] Double Lab[E])
		  </br>Student number is optional.
		  <a href="http://www.JGhidossi.com/ExSchedules/Example%20Form.jpg">Click Here for an Example Form</a><br></font>
		  <font color="#ff0000" face="times new roman" size="2">
		  Note: Print themed schedules at your own discretion. Cat themes are a joke, America is not.<br></font>
		  <font color="#ffffff" face="times new roman" size="2">
		  Created by: Jordan Ghidossi<br/><br/>
		  Theme Examples:<br/></font>
		  <a href="http://www.JGhidossi.com/ExSchedules/Plain.jpg"><embed src="http://www.JGhidossi.com/ExSchedules/Plain.jpg" width="105" height="148.5"></a> &nbsp;
		  <a href="http://www.JGhidossi.com/ExSchedules/Colored.jpg"><embed src="http://www.JGhidossi.com/ExSchedules/Colored.jpg" width="105" height="148.5"></a> &nbsp;
		  <a href="http://www.JGhidossi.com/ExSchedules/Tigers.jpg"><embed src="http://www.JGhidossi.com/ExSchedules/Tigers.jpg" width="105" height="148.5"></a> &nbsp;
		  <a href="http://www.JGhidossi.com/ExSchedules/America.jpg"><embed src="http://www.JGhidossi.com/ExSchedules/America.jpg" width="105" height="148.5"></a> &nbsp;
		  <a href="http://www.JGhidossi.com/ExSchedules/Plain%20Cats.jpg"><embed src="http://www.JGhidossi.com/ExSchedules/Plain%20Cats.jpg" width="105" height="148.5"></a> &nbsp;
		  <a href="http://www.JGhidossi.com/ExSchedules/Colored%20Cats.jpg"><embed src="http://www.JGhidossi.com/ExSchedules/Colored%20Cats.jpg" width="105" height="148.5"></a> &nbsp;
		  <a href="http://www.JGhidossi.com/ExSchedules/RHS%20Cats.jpg"><embed src="http://www.JGhidossi.com/ExSchedules/RHS%20Cats.jpg" width="105" height="148.5"></a>
		  </div>
</div><div id="wsb-element-346378107" class="wsb-element-image" data-type="element"> <div class="wsb-image-inner "><div class="img"><img src="http://www.jghidossi.com/ExSchedules/Title.png" alt="" style="width:423px;height:106px;"></div></div> </div> </div></div><div id="wsb-canvas-template-footer" class="wsb-canvas-page-footer footer" style="margin: auto; min-height:100px; height: 100px; width: 950px; position: relative;"><div id="wsb-canvas-template-footer-container" class="footer-container" style="position: absolute">  </div></div><div class="view-as-mobile" style="padding:10px;position:relative;text-align:center;display:none;"><a href="#" onclick="return false;">View on Mobile</a></div></div></div><script type="text/javascript"> require(['jq!starfield/jquery.mod', 'modules/cookiemanager/cookiemanager', 'modules/iebackground/iebackground'], function ($, cookieManager, bg) { if (cookieManager.POSTCookie("WSB.ForceDesktop")) { $('.view-as-mobile', '.wsb-canvas-page-container').show().find('a').bind('click', function () { cookieManager.eraseCookie("WSB.ForceDesktop"); window.location.reload(true); }); } bg.fixBackground(); }); </script></body></html>